import { Link, useLocation, Outlet } from 'react-router-dom';
import {
  LayoutDashboard, MapPin, BarChart3, Orbit, BookOpen, Users, Settings,
} from 'lucide-react';
import { useCareer } from '../context/CareerContext';

const mainNavItems = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/waypoint', label: 'My Roadmap', icon: MapPin },
  { to: '/flight-log', label: 'Flight Log', icon: BarChart3 },
];

const secondaryNavItems = [
  { to: '/flight-log', label: 'Mentorship', icon: Users },
  { to: '/flight-log', label: 'Settings', icon: Settings },
];

export default function DashboardLayout() {
  const location = useLocation();
  const { profile, goalInput } = useCareer();

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 flex w-56 flex-col border-r border-white/[0.06] bg-space-950/95 backdrop-blur-xl">
        {/* Logo area */}
        <div className="flex h-14 items-center border-b border-white/[0.06] px-4">
          <Logo />
        </div>

        {/* Trajectory label */}
        <div className="px-4 pt-5 pb-2">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-cyan-400" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-cyan-400/80">Trajectory</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const active = location.pathname === item.to;
            return (
              <Link
                key={item.to + item.label}
                to={item.to}
                className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
                  active
                    ? 'bg-cyan-400/15 text-white'
                    : 'text-slate-400 hover:bg-white/[0.04] hover:text-white'
                }`}
              >
                <Icon className={`h-4 w-4 shrink-0 ${active ? 'text-cyan-400' : ''}`} />
                {item.label}
              </Link>
            );
          })}

          <div className="pt-3 pb-1">
            <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.15em] text-slate-600">Community</span>
          </div>
          {secondaryNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.label}
                to={item.to}
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-slate-500 transition-all hover:bg-white/[0.04] hover:text-white"
              >
                <Icon className="h-4 w-4 shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        {/* Dynamic goal indicator */}
        {goalInput && (
          <div className="mx-2 mb-2 rounded-lg border border-cyan-400/10 bg-cyan-400/[0.04] px-3 py-2">
            <p className="text-[9px] font-semibold uppercase tracking-widest text-cyan-400/60">Goal</p>
            <p className="mt-0.5 truncate text-[11px] font-semibold text-white">{profile.targetRole}</p>
            <p className="truncate text-[9px] text-slate-500">{profile.category} · {profile.avgSalary}</p>
          </div>
        )}

        {/* User footer */}
        <div className="border-t border-white/[0.06] p-3">
          <div className="flex items-center gap-2.5 rounded-lg bg-white/[0.03] px-3 py-2">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 text-xs font-bold text-space-950">
              TT
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">Alex Rivera</p>
              <p className="truncate text-[10px] text-cyan-300/70">
                {goalInput ? `→ ${profile.goalTitle}` : 'Set your goal'}
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex min-h-screen flex-1 flex-col pl-56">
        <Outlet />
      </div>
    </div>
  );
}

export function Logo({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 shadow-lg shadow-cyan-500/30">
        <Orbit className="h-4 w-4 text-space-950" />
      </div>
      <div className="flex flex-col leading-none">
        <span className="text-sm font-bold tracking-tight text-white">CareerOS</span>
        <span className="text-[9px] font-medium uppercase tracking-[0.15em] text-cyan-400/60">AI-Powered</span>
      </div>
    </div>
  );
}
