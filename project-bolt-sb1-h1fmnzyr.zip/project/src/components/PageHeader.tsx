import { Logo } from './DashboardLayout';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function PageHeader({
  eyebrow,
  title,
  subtitle,
  back,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  back?: string;
}) {
  return (
    <header className="border-b border-white/5 bg-space-950/60 backdrop-blur-xl sticky top-0 z-30">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3.5 sm:px-6">
        <div className="flex items-center gap-4">
          {back && (
            <Link
              to={back}
              className="hidden h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-slate-400 transition hover:bg-white/5 hover:text-white sm:flex"
              title="Back"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
          )}
          <Logo />
        </div>
        <div className="text-right">
          {eyebrow && <p className="text-[10px] font-medium uppercase tracking-[0.2em] text-cyan-400/70">{eyebrow}</p>}
          <p className="text-sm font-semibold text-white">{title}</p>
          {subtitle && <p className="hidden text-xs text-slate-400 sm:block">{subtitle}</p>}
        </div>
      </div>
    </header>
  );
}
