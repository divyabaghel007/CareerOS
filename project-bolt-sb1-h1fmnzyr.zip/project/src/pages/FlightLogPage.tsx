import { useState } from 'react';
import {
  Clock, Flag, Package, Timer, BookOpen, CheckCircle2, Rocket, Calendar,
  LayoutGrid, Waves, Flame, Award, Target, Trophy, ChevronRight, TrendingUp,
  Download,
} from 'lucide-react';
import {
  progressHistory, badges, learningStats, userProfile,
} from '../data/roadmap';
import { useCareer } from '../context/CareerContext';

const statsIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Clock, Flag, Package, Timer, BookOpen, CheckCircle2,
};
const badgeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Rocket, Calendar, LayoutGrid, Waves, Flame, Award, Target, Trophy,
};
const rarityStyles: Record<string, { ring: string; bg: string; label: string; labelColor: string; iconColor: string }> = {
  common:    { ring: 'border-slate-500/30',  bg: 'from-slate-500/10 to-slate-600/5',    label: 'Common',    labelColor: 'text-slate-400',  iconColor: 'text-slate-400' },
  rare:      { ring: 'border-cyan-400/40',   bg: 'from-cyan-400/10 to-blue-500/5',      label: 'Rare',      labelColor: 'text-cyan-300',   iconColor: 'text-cyan-300' },
  epic:      { ring: 'border-violet-400/40', bg: 'from-violet-400/10 to-fuchsia-500/5', label: 'Epic',      labelColor: 'text-violet-300', iconColor: 'text-violet-300' },
  legendary: { ring: 'border-amber-400/50',  bg: 'from-amber-400/15 to-orange-500/5',   label: 'Legendary', labelColor: 'text-amber-300',  iconColor: 'text-amber-300' },
};

const tabs = ['Overview', 'Achievements', 'Settings'];

export default function FlightLogPage() {
  const [activeTab, setActiveTab] = useState('Overview');
  const { profile } = useCareer();

  const maxHours = Math.max(...progressHistory.map((p) => p.hours));

  const circularMetrics = [
    { label: 'Technical', value: 72, color: '#22d3ee' },
    { label: 'Directed', value: 54, color: '#fbbf24' },
    { label: 'Bonus', value: 81, color: '#818cf8' },
  ];

  // Build skill growth from profile radar skills
  const skillGrowthData = profile.radarSkills.map((s) => ({
    skill: s.skill,
    start: Math.max(s.value - Math.round(s.value * 0.35), 10),
    current: s.value,
    change: Math.round(s.value * 0.35),
  }));

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-white/[0.06] bg-space-950/90 backdrop-blur-xl">
        <div className="flex items-center justify-between px-6 py-3">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-cyan-400/60">Flight Log</p>
            <p className="text-sm font-semibold text-white">Profile & Progress</p>
          </div>
          <div className="flex items-center gap-1">
            {tabs.map((t) => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                className={`px-4 py-2 text-xs font-medium rounded-lg transition ${
                  activeTab === t ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 text-xs font-bold text-space-950">
            {userProfile.avatarInitials}
          </div>
        </div>
      </header>

      <main className="px-6 py-6">
        {/* Profile card */}
        <section className="glass relative overflow-hidden rounded-2xl p-5 mb-6">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(34,211,238,0.08),transparent_60%)]" />
          <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-400 to-cyan-600 text-xl font-bold text-space-950 shadow-lg shadow-cyan-500/20">
                  {userProfile.avatarInitials}
                </div>
                <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full border-2 border-space-900 bg-amber-400 text-[10px] font-bold text-space-950">
                  {userProfile.level}
                </span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">CareerOS</h1>
                <p className="text-xs font-medium uppercase tracking-widest text-cyan-300/80">
                  Target · {profile.targetRole}
                </p>
                <p className="mt-1 text-[10px] text-slate-500">
                  Navigating since {userProfile.joined} · 312 hrs logged · 3 certificates
                </p>
              </div>
            </div>
            <div className="shrink-0 space-y-1 text-right hidden sm:block">
              <p className="text-[10px] text-slate-500">{profile.category}</p>
              <p className="text-sm font-semibold text-white">{profile.currentRole} → {profile.targetRole}</p>
              <p className="text-[10px] text-slate-500">{profile.demand} demand · Avg {profile.avgSalary}</p>
            </div>
            <button className="glass-hover shrink-0 rounded-xl border border-white/10 px-4 py-2 text-xs font-semibold text-white transition">
              Edit Profile
            </button>
          </div>
        </section>

        {/* Circular progress metrics */}
        <section className="mb-6 glass rounded-2xl p-5">
          <div className="flex flex-wrap items-center justify-around gap-8">
            {circularMetrics.map((m) => (
              <CircularStat key={m.label} label={m.label} value={m.value} color={m.color} />
            ))}
          </div>
        </section>

        {/* Two-column: chart + badges */}
        <div className="mb-6 grid gap-6 lg:grid-cols-5">
          {/* Skill action over time */}
          <section className="glass rounded-2xl p-5 lg:col-span-3">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="font-semibold text-white">Skill Action Over Time</h2>
                <p className="text-xs text-slate-500">Study hours · last 12 weeks</p>
              </div>
              <span className="flex items-center gap-1 text-xs text-emerald-300">
                <TrendingUp className="h-3.5 w-3.5" /> +18% trend
              </span>
            </div>
            <SkillLineChart data={progressHistory.map((p) => p.hours)} labels={progressHistory.map((p) => p.week)} max={maxHours} />
            <div className="mt-4 flex justify-between border-t border-white/5 pt-3 text-xs text-slate-500">
              <span>Last saved 2 hours ago</span>
              <span>Next sync in 3h</span>
            </div>
          </section>

          {/* Badges earned */}
          <section className="glass rounded-2xl p-5 lg:col-span-2">
            <div className="mb-4">
              <h2 className="font-semibold text-white">Badges Earned</h2>
              <p className="text-xs text-slate-500">{badges.filter((b) => b.earned).length} of {badges.length}</p>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {badges.slice(0, 6).map((b) => {
                const Icon = badgeIcons[b.icon] ?? Award;
                const r = rarityStyles[b.rarity];
                return (
                  <div key={b.id} title={b.name}
                    className={`relative flex flex-col items-center rounded-xl border ${r.ring} bg-gradient-to-br ${r.bg} p-3 text-center ${!b.earned ? 'opacity-40 grayscale' : ''}`}
                  >
                    <div className={`flex h-9 w-9 items-center justify-center rounded-full ring-1 ${r.ring} bg-gradient-to-br ${r.bg}`}>
                      <Icon className={`h-4 w-4 ${b.earned ? r.iconColor : 'text-slate-600'}`} />
                    </div>
                    <p className="mt-1 text-[9px] font-semibold leading-tight text-white">{b.name}</p>
                    {b.earned ? (
                      <p className="text-[8px] text-emerald-300">{b.date}</p>
                    ) : (
                      <p className="text-[8px] text-slate-600">Locked</p>
                    )}
                    <span className={`absolute right-1 top-1 text-[7px] font-bold uppercase ${r.labelColor}`}>{r.label[0]}</span>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 border-t border-white/5 pt-4">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400">Way Badge · {profile.goalTitle} Specialist</span>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
                <div className="h-full w-[82%] rounded-full bg-gradient-to-r from-violet-400 to-violet-300" />
              </div>
              <p className="mt-1.5 text-[10px] text-slate-600">
                Clear {profile.currentWaypoint.code} to unlock · 82% of the way there
              </p>
            </div>
          </section>
        </div>

        {/* Learning stats */}
        <section className="mb-6 grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-6">
          {learningStats.map((stat) => {
            const Icon = statsIcons[stat.icon] ?? Clock;
            return (
              <div key={stat.label} className="glass glass-hover rounded-2xl p-4">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-400/10 text-cyan-300">
                  <Icon className="h-4 w-4" />
                </div>
                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-white">{stat.value}</span>
                  {stat.unit && <span className="text-sm text-slate-500">{stat.unit}</span>}
                </div>
                <div className="text-xs font-medium text-slate-300">{stat.label}</div>
                <div className="text-[10px] text-slate-500">{stat.sub}</div>
              </div>
            );
          })}
        </section>

        {/* Skill growth — dynamic from profile */}
        <section className="mb-6 glass rounded-2xl p-5">
          <div className="mb-4">
            <h2 className="font-semibold text-white">Skill Growth</h2>
            <p className="text-xs text-slate-400">
              {profile.goalTitle} path · starting vs current competency
            </p>
          </div>
          <div className="space-y-3">
            {skillGrowthData.map((s) => (
              <div key={s.skill}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-300">{s.skill}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-600">+{s.change}</span>
                    <span className="font-semibold text-cyan-300">{s.current}</span>
                  </div>
                </div>
                <div className="relative h-2.5 overflow-hidden rounded-full bg-white/5">
                  <div className="absolute inset-y-0 left-0 rounded-full bg-white/10" style={{ width: `${s.start}%` }} />
                  <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-cyan-400 to-cyan-300 transition-all duration-700" style={{ width: `${s.current}%` }} />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Recent activity — dynamic titles reference the goal */}
        <section className="glass rounded-2xl p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold text-white">Recent Flight Activity</h2>
            <button className="flex items-center gap-1.5 rounded-xl border border-white/10 px-3 py-1.5 text-xs text-slate-400 transition hover:border-white/20 hover:text-white">
              <Download className="h-3 w-3" /> Download Flight Log
            </button>
          </div>
          <div className="space-y-2">
            {[
              { icon: CheckCircle2, color: 'text-emerald-400', title: `Completed "${profile.currentWaypoint.title.split(':')[0]}" module`, meta: `${profile.currentWaypoint.phase} · 2h ago` },
              { icon: Flame, color: 'text-amber-400', title: 'Reached 23-day study streak', meta: 'New personal record · 6h ago' },
              { icon: Award, color: 'text-cyan-300', title: 'Earned "Deep Diver" badge', meta: '100+ study hours · yesterday' },
              { icon: Package, color: 'text-violet-300', title: `Milestone: ${profile.phases[0]?.title ?? 'Phase 1'} completed`, meta: 'Roadmap progress · 2 days ago' },
              { icon: BookOpen, color: 'text-cyan-300', title: `Finished ${profile.skills[0] ?? 'core skill'} fundamentals`, meta: 'Learning progress · 3 days ago' },
            ].map((act, i) => {
              const Icon = act.icon;
              return (
                <div key={i} className="flex items-center gap-3 rounded-xl bg-white/[0.02] px-3 py-2.5">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/[0.04]">
                    <Icon className={`h-4 w-4 ${act.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white">{act.title}</p>
                    <p className="text-[10px] text-slate-500">{act.meta}</p>
                  </div>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-slate-700" />
                </div>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}

function CircularStat({ label, value, color }: { label: string; value: number; color: string }) {
  const size = 100, strokeWidth = 7, r = (size - strokeWidth) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative flex items-center justify-center">
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={strokeWidth} />
          <circle
            cx={size / 2} cy={size / 2} r={r} fill="none"
            stroke={color} strokeWidth={strokeWidth}
            strokeDasharray={circ} strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute text-center">
          <p className="text-xl font-bold text-white">{value}%</p>
        </div>
      </div>
      <p className="text-[10px] font-semibold uppercase tracking-widest text-slate-500">{label}</p>
    </div>
  );
}

function SkillLineChart({ data, labels, max }: { data: number[]; labels: string[]; max: number }) {
  const W = 500, H = 160, pad = 20;
  const innerW = W - pad * 2, innerH = H - pad * 2 - 20;
  const stepX = innerW / (data.length - 1);
  const pts = data.map((v, i) => ({ x: pad + i * stepX, y: pad + innerH - (v / max) * innerH }));
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const areaPath = `${path} L${pts[pts.length - 1].x},${pad + innerH} L${pts[0].x},${pad + innerH} Z`;
  const maxIdx = data.indexOf(max);

  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" preserveAspectRatio="xMidYMid meet" style={{ height: 160 }}>
        <defs>
          <linearGradient id="fl-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="rgba(129,140,248,0.35)" />
            <stop offset="100%" stopColor="rgba(129,140,248,0)" />
          </linearGradient>
        </defs>
        {[0, 0.33, 0.66, 1].map((g) => (
          <line key={g} x1={pad} y1={pad + innerH * g} x2={pad + innerW} y2={pad + innerH * g} stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
        ))}
        <path d={areaPath} fill="url(#fl-grad)" />
        <path d={path} fill="none" stroke="#818cf8" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
        {pts.map((p, i) => (
          <g key={i}>
            {i === maxIdx ? (
              <>
                <circle cx={p.x} cy={p.y} r={6} fill="rgba(251,191,36,0.2)" />
                <circle cx={p.x} cy={p.y} r={4} fill="#fbbf24" />
              </>
            ) : (
              <circle cx={p.x} cy={p.y} r={2.5} fill="#818cf8" />
            )}
            <text x={p.x} y={H - 5} textAnchor="middle" fontSize="7" fill="#475569">{labels[i]}</text>
          </g>
        ))}
      </svg>
    </div>
  );
}
