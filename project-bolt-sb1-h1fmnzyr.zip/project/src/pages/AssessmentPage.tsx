import { useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, Check, Rocket, Satellite, Radar, Compass,
  Sparkles, BrainCircuit,
} from 'lucide-react';
import { Logo } from '../components/DashboardLayout';
import { availableSkills, experienceLevels, weeklyCommitments } from '../data/roadmap';
import { useCareer } from '../context/CareerContext';

const expIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  Rocket, Satellite, Radar, Compass,
};

const stepLabels = [
  { label: 'Skills', icon: Sparkles },
  { label: 'Experience', icon: BrainCircuit },
  { label: 'Preferences', icon: Radar },
];

const quickSkills = ['Python', 'SQL', 'Figma', 'Leadership', 'Public Speaking', 'Data Analysis', 'Project Mgmt', 'Excel', 'A/B Testing', 'Stakeholder Mgmt'];

import { useState } from 'react';

export default function AssessmentPage() {
  const nav = useNavigate();
  const {
    goalInput, setGoalInput,
    profile,
    experience, setExperience,
    weeklyHours, setWeeklyHours,
    selectedSkills, setSelectedSkills,
  } = useCareer();

  const [step, setStep] = useState(0);
  const [customSkill, setCustomSkill] = useState('');

  const toggleSkill = (name: string) =>
    setSelectedSkills(selectedSkills.includes(name) ? selectedSkills.filter((s) => s !== name) : [...selectedSkills, name]);

  const addCustomSkill = () => {
    const trimmed = customSkill.trim();
    if (trimmed && !selectedSkills.includes(trimmed)) {
      setSelectedSkills([...selectedSkills, trimmed]);
    }
    setCustomSkill('');
  };

  const canContinue = step === 0 ? selectedSkills.length >= 1 : step === 1 ? !!experience : true;
  const finish = () => nav('/dashboard');

  // Dynamic navigator messages based on goal
  const navigatorMessages = [
    profile.navigatorNotes[0] ?? 'I\'ll weight your roadmap based on your selected skills.',
    profile.navigatorNotes[1] ?? 'Your experience level calibrates the depth and pacing of each module.',
    profile.navigatorNotes[2] ?? 'Navigator AI re-plots your trajectory any time your skills, goal, or pace change.',
  ];

  // Roadmap preview from profile
  const roadmapPreview = [
    { id: 'wp01', label: `WP-01 ${profile.phases[0]?.title ?? 'Foundations'}`, status: 'done' as const },
    { id: 'wp02', label: `WP-02 ${profile.phases[1]?.title ?? 'Core Skills'}`, status: 'active' as const, progress: 40 },
    { id: 'wp03', label: `WP-03 ${profile.phases[2]?.title ?? 'Specialization'}`, status: 'locked' as const },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-0 starfield-overlay opacity-25" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-10%,rgba(34,211,238,0.10),transparent)]" />

      {/* Top nav */}
      <nav className="relative z-20 border-b border-white/[0.06] bg-space-950/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-1.5 text-sm text-slate-400 transition hover:text-white">
              <ArrowLeft className="h-4 w-4" /> Back to Home
            </Link>
            <span className="text-slate-700">/</span>
            <Logo />
          </div>

          {/* Step progress */}
          <div className="flex items-center gap-1">
            {stepLabels.map((s, i) => {
              const done = i < step;
              const active = i === step;
              return (
                <div key={s.label} className="flex items-center gap-1">
                  <div className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-[10px] font-semibold transition-all ${
                    done ? 'bg-cyan-400/20 text-cyan-300' : active ? 'bg-white/10 text-white' : 'text-slate-600'
                  }`}>
                    {done ? <Check className="h-3 w-3" /> : <span className="font-mono">{String(i + 1).padStart(2, '0')}</span>}
                    {s.label}
                  </div>
                  {i < stepLabels.length - 1 && (
                    <div className={`h-px w-6 ${i < step ? 'bg-cyan-400/50' : 'bg-white/10'}`} />
                  )}
                </div>
              );
            })}
          </div>

          <button onClick={finish} className="text-xs text-slate-500 transition hover:text-white">Save & Exit</button>
        </div>
      </nav>

      <main className="relative z-10 mx-auto max-w-7xl px-5 py-8 sm:px-6">
        {/* Goal banner */}
        {goalInput && (
          <div className="mb-6 flex items-center justify-between rounded-xl border border-cyan-400/20 bg-cyan-400/[0.04] px-4 py-3">
            <div className="flex items-center gap-3">
              <Sparkles className="h-4 w-4 text-cyan-300" />
              <div>
                <span className="text-xs text-slate-400">Career goal: </span>
                <span className="text-sm font-semibold text-white">{profile.targetRole}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-500">
              <span>{profile.avgSalary} avg</span>
              <span>·</span>
              <span>{profile.demand} demand</span>
              <span>·</span>
              <span>~{profile.timelineMonths} months</span>
            </div>
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-5">
          {/* Main form — 3 cols */}
          <div className="lg:col-span-3">

            {/* Step 0: Skills */}
            {step === 0 && (
              <div className="animate-fade-in-up">
                <h1 className="text-2xl font-bold text-white">What skills do you bring?</h1>
                <p className="mt-1.5 text-sm text-slate-400">Select everything that applies — Navigator AI will weight your {profile.goalTitle} roadmap accordingly.</p>

                {/* Goal-specific recommended skills */}
                {profile.skills.length > 0 && (
                  <div className="mt-4 rounded-xl border border-cyan-400/15 bg-cyan-400/[0.03] p-3">
                    <p className="mb-2 text-[10px] font-semibold uppercase tracking-widest text-cyan-400/70">
                      Key skills for {profile.goalTitle}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {profile.skills.map((s) => {
                        const active = selectedSkills.includes(s);
                        return (
                          <button
                            key={s}
                            onClick={() => toggleSkill(s)}
                            className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium transition-all ${
                              active
                                ? 'border-cyan-400/50 bg-cyan-400/15 text-cyan-200'
                                : 'border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/20 hover:text-white'
                            }`}
                          >
                            {active && <Check className="h-3 w-3" />}
                            {s}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="mt-4 flex flex-wrap gap-2">
                  {quickSkills.map((s) => {
                    const active = selectedSkills.includes(s);
                    return (
                      <button
                        key={s}
                        onClick={() => toggleSkill(s)}
                        className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium transition-all ${
                          active
                            ? 'border-cyan-400/50 bg-cyan-400/15 text-cyan-200'
                            : 'border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/20 hover:text-white'
                        }`}
                      >
                        {active && <Check className="h-3 w-3" />}
                        {s}
                      </button>
                    );
                  })}
                </div>

                {/* Full skill list grouped */}
                <div className="mt-5 space-y-4">
                  {Object.entries(
                    availableSkills.reduce<Record<string, typeof availableSkills>>((acc, s) => {
                      (acc[s.category] ||= []).push(s);
                      return acc;
                    }, {})
                  ).map(([cat, skills]) => (
                    <div key={cat}>
                      <h3 className="mb-2 text-[10px] font-semibold uppercase tracking-[0.15em] text-slate-500">{cat}</h3>
                      <div className="flex flex-wrap gap-1.5">
                        {skills.map((s) => {
                          const active = selectedSkills.includes(s.name);
                          return (
                            <button
                              key={s.id}
                              onClick={() => toggleSkill(s.name)}
                              className={`flex items-center gap-1 rounded-lg border px-2.5 py-1 text-xs transition-all ${
                                active
                                  ? 'border-cyan-400/50 bg-cyan-400/15 text-cyan-200'
                                  : 'border-white/10 bg-white/[0.02] text-slate-400 hover:border-white/20 hover:text-white'
                              }`}
                            >
                              {active && <Check className="h-3 w-3" />}
                              {s.name}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Custom skill input */}
                <div className="mt-4 glass rounded-xl p-3">
                  <div className="flex items-center gap-2">
                    <input
                      value={customSkill}
                      onChange={(e) => setCustomSkill(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addCustomSkill()}
                      placeholder="Add a custom skill..."
                      className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-600 focus:outline-none"
                    />
                    <button
                      onClick={addCustomSkill}
                      className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/5 text-slate-400 transition hover:bg-cyan-400/20 hover:text-cyan-300"
                    >
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Step 1: Experience */}
            {step === 1 && (
              <div className="animate-fade-in-up">
                <h1 className="text-2xl font-bold text-white">Experience level?</h1>
                <p className="mt-1.5 text-sm text-slate-400">Your starting altitude shapes the difficulty and pacing of your {profile.goalTitle} roadmap.</p>
                <div className="mt-6 grid gap-3 sm:grid-cols-3">
                  {[
                    { id: 'beginner', label: 'Beginner', years: '0–2 yrs' },
                    { id: 'mid', label: 'Intermediate', years: '2–5 yrs' },
                    { id: 'senior', label: 'Advanced', years: '5+ yrs' },
                  ].map((lvl) => {
                    const active = experience === lvl.id;
                    return (
                      <button
                        key={lvl.id}
                        onClick={() => setExperience(lvl.id)}
                        className={`glass glass-hover relative rounded-xl p-4 text-left transition-all ${
                          active ? 'border-cyan-400/60 ring-1 ring-cyan-400/30' : ''
                        }`}
                      >
                        {active && (
                          <div className="absolute top-3 right-3 flex h-4 w-4 items-center justify-center rounded-full bg-cyan-400">
                            <Check className="h-2.5 w-2.5 text-space-950" />
                          </div>
                        )}
                        <p className="font-semibold text-white">{lvl.label}</p>
                        <p className="mt-1 text-xs text-slate-500">{lvl.years}</p>
                      </button>
                    );
                  })}
                </div>

                <div className="mt-6">
                  <h2 className="mb-3 text-sm font-semibold text-white">Experience detail</h2>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {experienceLevels.map((lvl) => {
                      const Icon = expIcons[lvl.id] ?? Rocket;
                      const active = experience === lvl.id;
                      return (
                        <button
                          key={lvl.id}
                          onClick={() => setExperience(lvl.id)}
                          className={`glass glass-hover relative rounded-xl p-4 text-left transition-all ${
                            active ? 'border-cyan-400/60 ring-1 ring-cyan-400/30' : ''
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-400/10 text-cyan-300">
                              <Icon className="h-4 w-4" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-white">{lvl.title}</p>
                              <p className="text-[10px] text-slate-500">{lvl.years}</p>
                            </div>
                          </div>
                          <p className="mt-2 text-xs text-slate-400">{lvl.desc}</p>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Weekly commitment */}
            {step === 2 && (
              <div className="animate-fade-in-up">
                <h1 className="text-2xl font-bold text-white">Weekly time commitment?</h1>
                <p className="mt-1.5 text-sm text-slate-400">We'll tune your {profile.goalTitle} waypoint density to your cadence.</p>

                <div className="mt-6">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">Hours per week</span>
                    <span className="text-sm font-bold text-cyan-300">{weeklyHours} hrs</span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={30}
                    value={weeklyHours}
                    onChange={(e) => setWeeklyHours(Number(e.target.value))}
                    className="mt-3 w-full accent-cyan-400"
                  />
                  <div className="mt-1.5 flex justify-between text-[10px] text-slate-600">
                    <span>2 hrs</span><span>16 hrs</span><span>30 hrs</span>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {weeklyCommitments.map((c) => {
                    const active = weeklyHours === c.hours;
                    return (
                      <button
                        key={c.hours}
                        onClick={() => setWeeklyHours(c.hours)}
                        className={`glass glass-hover rounded-xl p-4 text-center transition-all ${
                          active ? 'border-cyan-400/60 ring-1 ring-cyan-400/30' : ''
                        }`}
                      >
                        <div className={`text-xl font-bold ${active ? 'text-cyan-300' : 'text-white'}`}>{c.label}</div>
                        <div className="mt-0.5 text-[10px] text-slate-500">/ week</div>
                        <div className="mt-2 text-[10px] uppercase tracking-wide text-slate-600">{c.subtitle}</div>
                      </button>
                    );
                  })}
                </div>

                <div className="glass mt-6 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-400/10 text-cyan-300">
                      <Sparkles className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Nothing here is permanent.</p>
                      <p className="mt-0.5 text-xs text-slate-400">
                        Navigator AI re-plots your {profile.goalTitle} trajectory any time your skills, goal, or pace change — you can edit anything later from Settings.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Nav buttons */}
            <div className="mt-8 flex items-center justify-between">
              <button
                onClick={() => (step === 0 ? nav('/') : setStep((s) => s - 1))}
                className="btn-secondary"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </button>
              {step < 2 ? (
                <button
                  onClick={() => setStep((s) => s + 1)}
                  disabled={!canContinue}
                  className="btn-primary group"
                >
                  Continue <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </button>
              ) : (
                <button onClick={finish} className="btn-primary group">
                  <Rocket className="h-4 w-4" />
                  Launch my roadmap
                </button>
              )}
            </div>
          </div>

          {/* Right sidebar — 2 cols */}
          <div className="space-y-4 lg:col-span-2">
            {/* Navigator AI */}
            <div className="glass rounded-2xl p-5">
              <div className="flex items-start gap-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400/20 to-cyan-600/10 text-cyan-300">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Navigator</p>
                  <p className="text-[10px] text-slate-500">AI co-pilot, real time.</p>
                </div>
              </div>
              <div className="mt-3 rounded-xl border border-cyan-400/10 bg-cyan-400/[0.03] p-3">
                <p className="text-sm leading-relaxed text-slate-300">
                  "{navigatorMessages[step]}"
                </p>
              </div>
            </div>

            {/* Roadmap preview */}
            <div className="glass rounded-2xl p-5">
              <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-500">Roadmap Preview</p>
              {goalInput && (
                <p className="mb-3 text-xs font-medium text-cyan-300">→ {profile.targetRole}</p>
              )}
              <div className="space-y-2">
                {roadmapPreview.map((wp) => (
                  <div key={wp.id} className={`flex items-center gap-3 rounded-lg p-2.5 ${
                    wp.status === 'active' ? 'bg-amber-400/5 border border-amber-400/20' : 'bg-white/[0.02]'
                  }`}>
                    <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                      wp.status === 'done' ? 'border-emerald-400 bg-emerald-400/20' :
                      wp.status === 'active' ? 'border-amber-400 bg-amber-400/20' :
                      'border-white/10 bg-transparent'
                    }`}>
                      {wp.status === 'done' && <Check className="h-3 w-3 text-emerald-400" />}
                      {wp.status === 'active' && <div className="h-2 w-2 rounded-full bg-amber-400" />}
                    </div>
                    <span className={`flex-1 text-xs ${
                      wp.status === 'done' ? 'text-slate-500 line-through' :
                      wp.status === 'active' ? 'font-medium text-white' :
                      'text-slate-500'
                    }`}>{wp.label}</span>
                    {wp.status === 'active' && wp.progress && (
                      <span className="text-[10px] text-amber-400">{wp.progress}%</span>
                    )}
                  </div>
                ))}
              </div>
              <p className="mt-4 text-[10px] text-slate-600">Matches update as you fill in your answers...</p>
            </div>

            {/* Selected skills summary */}
            {step === 0 && selectedSkills.length > 0 && (
              <div className="glass rounded-2xl p-4">
                <p className="mb-2.5 text-[10px] font-semibold uppercase tracking-wider text-slate-500">
                  Selected ({selectedSkills.length})
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedSkills.map((s) => (
                    <span key={s} className="flex items-center gap-1 rounded-lg bg-cyan-400/10 px-2 py-0.5 text-xs text-cyan-300">
                      {s}
                      <button onClick={() => toggleSkill(s)} className="ml-0.5 text-cyan-400/50 hover:text-cyan-200">×</button>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
