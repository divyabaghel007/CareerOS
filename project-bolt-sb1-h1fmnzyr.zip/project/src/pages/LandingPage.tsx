import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight, Layers, BrainCircuit, Server, ShieldCheck, Database, Smartphone,
} from 'lucide-react';
import { Logo } from '../components/DashboardLayout';
import { careerGoals } from '../data/roadmap';
import { useCareer } from '../context/CareerContext';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Layers, BrainCircuit, Server, ShieldCheck, Database, Smartphone,
};

const quickGoals = ['Data Analyst', 'Data Scientist', 'Product Manager', 'Full-Stack Engineer', 'UX Designer', 'DevOps Engineer'];

export default function LandingPage() {
  const { goalInput, setGoalInput, profile } = useCareer();
  const [localGoal, setLocalGoal] = useState(goalInput);
  const navigate = useNavigate();

  const handleStart = (g?: string) => {
    const finalGoal = g ?? localGoal;
    setGoalInput(finalGoal);
    navigate('/assessment');
  };

  const handleQuickPick = (q: string) => {
    setLocalGoal(q);
    setGoalInput(q);
  };

  const handleCardClick = (title: string) => {
    setLocalGoal(title);
    setGoalInput(title);
    navigate('/assessment');
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background */}
      <div className="pointer-events-none absolute inset-0 starfield-overlay opacity-40" />
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:64px_64px]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-10%,rgba(34,211,238,0.15),transparent)]" />

      {/* Nav */}
      <nav className="relative z-20 mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Logo />
        <div className="hidden items-center gap-8 text-sm text-slate-400 md:flex">
          <a href="#product" className="transition hover:text-white">Product</a>
          <a href="#how" className="transition hover:text-white">How it works</a>
          <a href="#pricing" className="transition hover:text-white">Pricing</a>
          <a href="#login" className="transition hover:text-white">Log in</a>
        </div>
        <button onClick={() => handleStart()} className="btn-primary !py-2 !px-5 text-sm">
          Get Started <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </nav>

      {/* Hero */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 pt-10 pb-16 lg:pt-16">
        <div className="grid lg:grid-cols-2 lg:gap-16 items-center">
          {/* Left: headline + input */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-cyan-400/80 mb-4">
              AI Career Navigator
            </p>
            <h1 className="text-5xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-6xl">
              Plot Your Course.<br />
              <span className="gradient-text">Let AI Navigate</span>{' '}
              <span className="text-white">The Rest.</span>
            </h1>
            <p className="mt-5 max-w-md text-base text-slate-300/80 leading-relaxed">
              Tell us where you are and where you want to go. Our AI plots the exact route — skills, milestones, and a realistic timeline to get you there.
            </p>

            {/* Goal input */}
            <div className="mt-8 glass rounded-2xl p-3 max-w-xl shadow-2xl shadow-cyan-500/10">
              {localGoal && (
                <div className="mb-2 flex items-center gap-2 px-1">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-slate-500">Your goal</span>
                  <ArrowRight className="h-3 w-3 text-slate-600" />
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-cyan-400">{localGoal}</span>
                </div>
              )}
              <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
                <input
                  value={localGoal}
                  onChange={(e) => setLocalGoal(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleStart()}
                  placeholder="Describe your career goal... e.g. Data Analyst"
                  className="flex-1 bg-transparent text-sm text-white placeholder:text-slate-500 focus:outline-none"
                />
                <button
                  onClick={() => handleStart()}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-400 text-space-950 transition hover:bg-cyan-300"
                >
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              <p className="mt-1.5 px-1 text-[10px] text-slate-600">Press ↵ to generate your roadmap instantly.</p>
            </div>

            {/* Quick picks */}
            <div className="mt-4 flex flex-wrap gap-2">
              {quickGoals.map((q) => (
                <button
                  key={q}
                  onClick={() => handleQuickPick(q)}
                  className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                    localGoal === q
                      ? 'border-cyan-400/50 bg-cyan-400/10 text-cyan-300'
                      : 'border-white/10 bg-white/[0.02] text-slate-400 hover:border-white/20 hover:text-white'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Stats row */}
            <div className="mt-10 grid grid-cols-3 gap-4">
              {[
                { value: '50K+', label: 'Roadmaps Plotted' },
                { value: '94%', label: 'On-Course Completion' },
                { value: '200+', label: 'Career Routes Served' },
              ].map((s) => (
                <div key={s.label}>
                  <div className="text-2xl font-bold text-white">{s.value}</div>
                  <div className="mt-0.5 text-[10px] font-medium uppercase tracking-wide text-slate-500">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: trajectory visualization */}
          <div className="relative hidden lg:block">
            <TrajectoryVisualization activeGoal={localGoal} />
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="relative z-10 mx-auto max-w-7xl px-6 py-16">
        <div className="grid grid-cols-3 gap-8">
          {[
            { n: '01', title: 'Tell us your goal', desc: 'Plain language, not a form.' },
            { n: '02', title: 'AI builds your route', desc: 'Milestones, skills, timing.' },
            { n: '03', title: 'Track every waypoint', desc: 'Mission Control keeps you on course.' },
          ].map((step) => (
            <div key={step.n} className="flex items-start gap-4">
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-cyan-400/30 bg-cyan-400/5 text-xs font-bold text-cyan-300">
                {step.n}
              </div>
              <div>
                <h3 className="font-semibold text-white">{step.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Career targets grid */}
      <section className="relative z-10 mx-auto max-w-7xl px-6 py-8 pb-20">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-widest text-cyan-400/70">Destination</p>
            <h2 className="mt-1 text-2xl font-bold text-white">Popular career targets</h2>
          </div>
          <button onClick={() => handleStart()} className="flex items-center gap-1.5 text-xs text-cyan-300 hover:text-cyan-200">
            View all <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {careerGoals.map((g) => {
            const Icon = iconMap[g.icon] ?? Layers;
            const active = localGoal === g.title;
            return (
              <button
                key={g.id}
                onClick={() => handleCardClick(g.title)}
                className={`glass glass-hover group rounded-xl p-4 text-left transition-all ${active ? 'border-cyan-400/40 ring-1 ring-cyan-400/20' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-400/10 text-cyan-300">
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className={`text-[10px] font-semibold uppercase tracking-wide ${
                    g.demand === 'Very High' ? 'text-emerald-300' : g.demand === 'High' ? 'text-cyan-300' : 'text-amber-300'
                  }`}>{g.demand}</span>
                </div>
                <h3 className="mt-3 text-sm font-semibold text-white">{g.title}</h3>
                <p className="text-[10px] text-slate-500">{g.category}</p>
                <div className="mt-3 flex items-center justify-between border-t border-white/5 pt-3">
                  <span className="text-xs font-semibold text-white">{g.avgSalary}</span>
                  <span className="text-xs text-cyan-300">{g.match}% match</span>
                </div>
              </button>
            );
          })}
        </div>
        <div className="mt-8 text-center">
          <button onClick={() => handleStart()} className="btn-primary group">
            Get Started <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/[0.05]">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
          <Logo />
          <p className="text-xs text-slate-600">© 2024 CareerOS. AI-Powered Career Roadmap Generator.</p>
          <div className="flex gap-5 text-xs text-slate-500">
            <a href="#" className="hover:text-white">Privacy</a>
            <a href="#" className="hover:text-white">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function TrajectoryVisualization({ activeGoal }: { activeGoal: string }) {
  const nodes = [
    { id: 'you', label: 'YOU ARE HERE', sub: '', x: 0.5, y: 0.88, type: 'current' },
    { id: 'foundations', label: 'WP-01', sub: 'Foundations', x: 0.38, y: 0.70, type: 'done' },
    { id: 'specialization', label: 'WP-02', sub: 'Core Skills', x: 0.52, y: 0.52, type: 'active' },
    { id: 'core', label: 'WP-03', sub: 'Specialization', x: 0.62, y: 0.35, type: 'locked' },
    { id: 'leadership', label: 'WP-04', sub: 'Leadership', x: 0.72, y: 0.20, type: 'locked' },
    { id: 'destination', label: 'DESTINATION', sub: activeGoal ? `Senior ${activeGoal}` : 'Your Goal', x: 0.85, y: 0.06, type: 'dest' },
  ];

  const W = 420, H = 380;
  const px = (p: number) => p * W;
  const py = (p: number) => p * H;

  const pathD = nodes
    .map((n, i) => `${i === 0 ? 'M' : 'L'}${px(n.x)},${py(n.y)}`)
    .join(' ');

  return (
    <div className="relative select-none">
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} className="w-full overflow-visible">
        <path d={pathD} fill="none" stroke="rgba(34,211,238,0.25)" strokeWidth="2" strokeDasharray="6 4" />
        {nodes.map((n) => {
          const cx = px(n.x), cy = py(n.y);
          if (n.type === 'dest') {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={14} fill="rgba(34,211,238,0.15)" stroke="#22d3ee" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={6} fill="#22d3ee" />
                <text x={cx} y={cy - 22} textAnchor="middle" fontSize="8" fill="#94a3b8" fontWeight="600" letterSpacing="2">{n.label}</text>
                <text x={cx} y={cy - 11} textAnchor="middle" fontSize="9" fill="white" fontWeight="700">{n.sub}</text>
              </g>
            );
          }
          if (n.type === 'current') {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={18} fill="rgba(34,211,238,0.08)" stroke="rgba(34,211,238,0.3)" strokeWidth="1" />
                <circle cx={cx} cy={cy} r={8} fill="rgba(34,211,238,0.3)" stroke="#22d3ee" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={4} fill="#22d3ee" />
                <text x={cx} y={cy + 30} textAnchor="middle" fontSize="8" fill="#94a3b8" fontWeight="600" letterSpacing="2">{n.label}</text>
              </g>
            );
          }
          if (n.type === 'done') {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={10} fill="rgba(52,211,153,0.15)" stroke="#34d399" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={4} fill="#34d399" />
                <text x={cx + 16} y={cy + 4} fontSize="9" fill="#94a3b8">{n.sub}</text>
              </g>
            );
          }
          if (n.type === 'active') {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={14} fill="rgba(251,191,36,0.12)" stroke="#fbbf24" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={6} fill="#fbbf24" />
                <text x={cx + 20} y={cy + 4} fontSize="9" fill="#fbbf24" fontWeight="600">{n.sub}</text>
              </g>
            );
          }
          return (
            <g key={n.id}>
              <circle cx={cx} cy={cy} r={9} fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.15)" strokeWidth="1" strokeDasharray="3 2" />
              <circle cx={cx} cy={cy} r={3} fill="rgba(255,255,255,0.2)" />
              <text x={cx + 15} y={cy + 4} fontSize="9" fill="#64748b">{n.sub}</text>
            </g>
          );
        })}
      </svg>
      <div className="absolute bottom-2 left-0 flex items-center gap-5 text-[9px] text-slate-500">
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-cyan-400/80" /> AI-driven</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-amber-400/80" /> Active</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full border border-white/20" /> Locked</span>
      </div>
    </div>
  );
}
