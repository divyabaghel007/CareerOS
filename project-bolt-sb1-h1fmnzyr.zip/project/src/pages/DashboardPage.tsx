import { Link } from 'react-router-dom';
import {
  TrendingUp, Clock, Flame, Gauge, CheckCircle2, Circle,
  ChevronRight, Bell, Search, ArrowRight, MapPin, Award, Target, Calendar,
} from 'lucide-react';
import { useState } from 'react';
import { kpiStats, userProfile } from '../data/roadmap';
import { useCareer } from '../context/CareerContext';

const kpiIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  TrendingUp, Clock, Flame, Gauge,
};
const kpiColorMap: Record<string, { text: string; bg: string }> = {
  cyan:    { text: 'text-cyan-300',    bg: 'bg-cyan-400/10' },
  emerald: { text: 'text-emerald-300', bg: 'bg-emerald-400/10' },
  amber:   { text: 'text-amber-300',   bg: 'bg-amber-400/10' },
  violet:  { text: 'text-violet-300',  bg: 'bg-violet-400/10' },
};

const TOTAL = 37;
const DONE = 14;

export default function DashboardPage() {
  const [search, setSearch] = useState('');
  const { profile, goalInput } = useCareer();

  const completedGoals = profile.weeklyGoals.filter((g) => g.done).length;
  const pct = Math.round((DONE / TOTAL) * 100);

  const activePhase = profile.phases.find((p) => p.status === 'active') ?? profile.phases[0];

  return (
    <div className="min-h-screen">
      {/* Top bar */}
      <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-white/[0.06] bg-space-950/90 px-6 backdrop-blur-xl">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative max-w-xs flex-1">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-600" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search resources, skills..."
              className="w-full rounded-lg border border-white/[0.06] bg-white/[0.03] py-1.5 pl-8 pr-3 text-xs text-white placeholder:text-slate-600 focus:border-cyan-400/30 focus:outline-none"
            />
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="relative flex h-8 w-8 items-center justify-center rounded-lg border border-white/[0.06] bg-white/[0.03] text-slate-400 transition hover:bg-white/[0.06] hover:text-white">
            <Bell className="h-4 w-4" />
            <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-cyan-400" />
          </button>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 text-xs font-bold text-space-950">
            {userProfile.avatarInitials}
          </div>
        </div>
      </header>

      <main className="px-6 py-6">
        {/* Title + overall progress */}
        <section className="mb-6 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Your Trajectory</h1>
            <p className="mt-0.5 text-sm text-slate-400">
              {profile.currentRole}
              <span className="mx-1.5 text-slate-600">→</span>
              <span className="text-cyan-300">{profile.targetRole}</span>
            </p>
            {goalInput && (
              <p className="mt-1 text-xs text-slate-600">
                {profile.category} · Avg {profile.avgSalary} · {profile.demand} demand · ~{profile.timelineMonths} months
              </p>
            )}
          </div>
          <div className="relative flex h-20 w-20 items-center justify-center">
            <CircularProgress value={pct} size={80} strokeWidth={6} color="#22d3ee" />
            <div className="absolute text-center">
              <div className="text-lg font-bold text-white">{pct}%</div>
              <div className="text-[8px] uppercase tracking-wide text-slate-500">on target</div>
            </div>
          </div>
        </section>

        {/* KPI strip */}
        <section className="mb-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {kpiStats.map((kpi) => {
            const Icon = kpiIcons[kpi.icon] ?? TrendingUp;
            const c = kpiColorMap[kpi.color];
            return (
              <div key={kpi.label} className="glass glass-hover rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-medium uppercase tracking-wide text-slate-500">{kpi.label}</p>
                  <div className={`flex h-7 w-7 items-center justify-center rounded-lg ${c.bg}`}>
                    <Icon className={`h-3.5 w-3.5 ${c.text}`} />
                  </div>
                </div>
                <div className={`mt-2 text-2xl font-bold ${c.text}`}>{kpi.value}</div>
                <div className="mt-0.5 text-[10px] text-slate-500">{kpi.sub}</div>
                <div className="mt-2 text-[10px] font-medium text-emerald-400">{kpi.trend}</div>
              </div>
            );
          })}
        </section>

        {/* Two column: trajectory map + right panel */}
        <div className="grid gap-6 lg:grid-cols-5">
          {/* Trajectory map */}
          <section className="lg:col-span-3">
            <div className="glass rounded-2xl p-5">
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-semibold text-white">Trajectory Map</h2>
                <Link to="/waypoint" className="flex items-center gap-1 text-xs text-cyan-300 hover:text-cyan-200">
                  View briefing <ChevronRight className="h-3.5 w-3.5" />
                </Link>
              </div>
              <TrajectoryMap phases={profile.phases} targetRole={profile.targetRole} />
            </div>
          </section>

          {/* Right panel */}
          <aside className="space-y-4 lg:col-span-2">
            {/* WP Next */}
            <div className="glass rounded-2xl p-5">
              <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.15em] text-cyan-400/70">WP Next</p>
              <h3 className="font-semibold text-white">{profile.currentWaypoint.title}</h3>
              <p className="mt-0.5 text-[10px] text-slate-500">{profile.currentWaypoint.phase}</p>
              <div className="mt-2">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span>{profile.currentWaypoint.progress}% complete · {profile.currentWaypoint.hoursLeft} hrs left</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
                  <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-300" style={{ width: `${profile.currentWaypoint.progress}%` }} />
                </div>
              </div>
              <Link to="/waypoint" className="btn-primary mt-4 block w-full text-center text-sm">
                Resume Mission
              </Link>
            </div>

            {/* Weekly goals */}
            <div className="glass rounded-2xl p-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-slate-500">This Week</p>
                <span className="rounded-full bg-cyan-400/10 px-2 py-0.5 text-[10px] font-semibold text-cyan-300">
                  {completedGoals}/{profile.weeklyGoals.length}
                </span>
              </div>
              <div className="space-y-2">
                {profile.weeklyGoals.slice(0, 4).map((g) => (
                  <div key={g.id} className="flex items-start gap-2.5 rounded-lg bg-white/[0.02] p-2">
                    {g.done ? (
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                    ) : (
                      <Circle className="mt-0.5 h-4 w-4 shrink-0 text-slate-600" />
                    )}
                    <p className={`text-xs ${g.done ? 'text-slate-600 line-through' : 'text-slate-300'}`}>
                      {g.title}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>

        {/* Bottom stats row */}
        <section className="mt-6 grid gap-4 sm:grid-cols-3">
          {[
            { label: 'Skills Mastered', value: '14', sub: 'this year' },
            { label: 'Goals Reached', value: '312', sub: 'this year' },
            { label: 'Certificates Earned', value: '3', sub: 'this year' },
          ].map((s) => (
            <div key={s.label} className="glass rounded-xl p-5 text-center">
              <div className="text-3xl font-bold text-white">{s.value}</div>
              <div className="mt-0.5 text-xs text-slate-500">{s.sub}</div>
              <div className="mt-1 text-[10px] font-medium uppercase tracking-widest text-slate-600">{s.label}</div>
            </div>
          ))}
        </section>

        {/* Quick actions */}
        <section className="mt-4 grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { to: '/waypoint', icon: MapPin, label: 'Open briefing', desc: `${profile.currentWaypoint.code} · ${activePhase?.title ?? 'Current phase'}` },
            { to: '/flight-log', icon: Calendar, label: 'View flight log', desc: 'Stats & badges' },
            { to: '/waypoint', icon: Award, label: 'Certifications', desc: profile.category },
            { to: '/assessment', icon: Target, label: 'Recalibrate', desc: goalInput ? `Goal: ${profile.goalTitle}` : 'Update mission' },
          ].map((a) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.label}
                to={a.to}
                className="glass-hover group flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3"
              >
                <Icon className="h-4 w-4 shrink-0 text-cyan-300" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{a.label}</div>
                  <div className="text-[10px] text-slate-500 truncate">{a.desc}</div>
                </div>
                <ArrowRight className="h-3.5 w-3.5 shrink-0 text-slate-600 transition group-hover:translate-x-0.5 group-hover:text-cyan-300" />
              </Link>
            );
          })}
        </section>

        {/* User footer card */}
        <div className="mt-6 flex items-center gap-4 rounded-xl border border-white/[0.05] bg-white/[0.02] px-5 py-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 text-sm font-bold text-space-950">
            {userProfile.avatarInitials}
          </div>
          <div>
            <p className="text-sm font-semibold text-white">CareerOS</p>
            <p className="text-[10px] text-slate-500">
              {profile.currentRole} → {profile.targetRole} · Px.{userProfile.level}
            </p>
          </div>
          <div className="ml-auto flex-1 max-w-xs">
            <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
              <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-300" style={{ width: `${(userProfile.xp / userProfile.xpToNext) * 100}%` }} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function CircularProgress({ value, size, strokeWidth, color }: {
  value: number; size: number; strokeWidth: number; color: string;
}) {
  const r = (size - strokeWidth) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={strokeWidth} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        stroke={color} strokeWidth={strokeWidth}
        strokeDasharray={circ} strokeDashoffset={offset}
        strokeLinecap="round"
      />
    </svg>
  );
}

function TrajectoryMap({ phases, targetRole }: {
  phases: { id: string; title: string; status: string; progress: number }[];
  targetRole: string;
}) {
  const nodes = phases.map((p, i) => ({
    ...p,
    x: 0.10 + i * (0.70 / Math.max(phases.length - 1, 1)),
    y: 0.85 - i * (0.60 / Math.max(phases.length - 1, 1)),
  }));

  const dest = { label: targetRole, x: nodes[nodes.length - 1].x + 0.12, y: nodes[nodes.length - 1].y - 0.10 };

  const W = 520, H = 280;
  const px = (p: number) => Math.min(p * W, W - 10);
  const py = (p: number) => Math.max(Math.min(p * H, H - 10), 5);

  const allPts = [...nodes.map((n) => ({ x: px(n.x), y: py(n.y) })), { x: px(dest.x), y: py(dest.y) }];
  const curvePath = allPts.map((pt, i) => {
    if (i === 0) return `M${pt.x},${pt.y}`;
    const prev = allPts[i - 1];
    const cpx = (prev.x + pt.x) / 2;
    return `Q${cpx},${prev.y} ${pt.x.toFixed(1)},${pt.y.toFixed(1)}`;
  }).join(' ');

  return (
    <div className="w-full overflow-hidden">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height: 280 }}>
        <path d={curvePath} fill="none" stroke="rgba(34,211,238,0.20)" strokeWidth="2" />
        <path d={curvePath} fill="none" stroke="rgba(34,211,238,0.06)" strokeWidth="12" />

        {nodes.map((n) => {
          const cx = px(n.x), cy = py(n.y);
          const isCurrent = n.status === 'active';
          const isDone = n.status === 'completed';
          if (isCurrent) {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={18} fill="rgba(251,191,36,0.08)" stroke="rgba(251,191,36,0.3)" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={10} fill="rgba(251,191,36,0.2)" stroke="#fbbf24" strokeWidth="2" />
                <circle cx={cx} cy={cy} r={4} fill="#fbbf24" />
                <text x={cx} y={cy + 28} textAnchor="middle" fontSize="9" fill="#fbbf24" fontWeight="600">{n.title.split(' ')[0]}</text>
                <text x={cx} y={cy - 26} textAnchor="middle" fontSize="7" fill="#94a3b8" letterSpacing="1">● YOU ARE HERE</text>
              </g>
            );
          }
          if (isDone) {
            return (
              <g key={n.id}>
                <circle cx={cx} cy={cy} r={10} fill="rgba(52,211,153,0.15)" stroke="#34d399" strokeWidth="1.5" />
                <circle cx={cx} cy={cy} r={4} fill="#34d399" />
                <text x={cx} y={cy + 22} textAnchor="middle" fontSize="9" fill="#94a3b8">{n.title.split(' ')[0]}</text>
              </g>
            );
          }
          return (
            <g key={n.id}>
              <circle cx={cx} cy={cy} r={9} fill="rgba(255,255,255,0.02)" stroke="rgba(255,255,255,0.12)" strokeWidth="1" strokeDasharray="3 2" />
              <circle cx={cx} cy={cy} r={3} fill="rgba(255,255,255,0.15)" />
              <text x={cx} y={cy + 20} textAnchor="middle" fontSize="9" fill="#475569">{n.title.split(' ')[0]}</text>
            </g>
          );
        })}

        {/* Destination */}
        <g>
          <circle cx={px(dest.x)} cy={py(dest.y)} r={14} fill="rgba(34,211,238,0.10)" stroke="#22d3ee" strokeWidth="1.5" />
          <circle cx={px(dest.x)} cy={py(dest.y)} r={5} fill="#22d3ee" />
          <text x={px(dest.x)} y={py(dest.y) + 24} textAnchor="middle" fontSize="9" fill="white" fontWeight="600">
            {dest.label.length > 20 ? dest.label.slice(0, 18) + '…' : dest.label}
          </text>
        </g>
      </svg>

      {/* Phase list below map */}
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4 border-t border-white/5 pt-3">
        {phases.map((p) => (
          <div key={p.id} className="flex items-center gap-2">
            <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${
              p.status === 'completed' ? 'bg-emerald-400' : p.status === 'active' ? 'bg-amber-400 animate-pulse' : 'bg-slate-600'
            }`} />
            <div className="min-w-0">
              <p className="truncate text-[10px] font-medium text-slate-300">{p.title}</p>
              <div className="mt-0.5 h-1 overflow-hidden rounded-full bg-white/5">
                <div className={`h-full rounded-full ${
                  p.status === 'completed' ? 'bg-emerald-400' : p.status === 'active' ? 'bg-amber-400' : 'bg-slate-700'
                }`} style={{ width: `${p.progress}%` }} />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
