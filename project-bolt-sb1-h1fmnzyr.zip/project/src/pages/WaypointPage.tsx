import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  BookOpen, Terminal, PlayCircle, Boxes, Users, Star, Clock, Award,
  CheckCircle2, ChevronRight, Target, ChevronLeft,
} from 'lucide-react';
import { resources } from '../data/roadmap';
import { useCareer } from '../context/CareerContext';

const resourceIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  BookOpen, Terminal, PlayCircle, Boxes, Users,
};

const tabs = ['Overview', 'Resources', 'Practice', 'Community'];

export default function WaypointPage() {
  const [activeTab, setActiveTab] = useState('Resources');
  const [markedDone, setMarkedDone] = useState(false);
  const { profile } = useCareer();

  const wp = profile.currentWaypoint;
  const activePhase = profile.phases.find((p) => p.status === 'active') ?? profile.phases[0];

  const size = 200, center = size / 2, maxR = center - 28, rings = 4;
  const angleStep = (Math.PI * 2) / profile.radarSkills.length;

  const pointFor = (val: number, i: number) => {
    const a = -Math.PI / 2 + i * angleStep;
    const r = (val / 100) * maxR;
    return { x: center + r * Math.cos(a), y: center + r * Math.sin(a) };
  };
  const labelPos = (i: number) => {
    const a = -Math.PI / 2 + i * angleStep;
    return { x: center + (maxR + 14) * Math.cos(a), y: center + (maxR + 14) * Math.sin(a) };
  };
  const polygonPts = profile.radarSkills.map((s, i) => {
    const p = pointFor(s.value, i);
    return `${p.x},${p.y}`;
  }).join(' ');
  const targetPts = profile.radarSkills.map((s, i) => {
    const p = pointFor(s.target, i);
    return `${p.x},${p.y}`;
  }).join(' ');

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-white/[0.06] bg-space-950/90 backdrop-blur-xl">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ChevronLeft className="h-3.5 w-3.5" />
            <Link to="/dashboard" className="hover:text-white transition">Mission Control</Link>
            <ChevronRight className="h-3 w-3" />
            <span className="text-slate-400">{activePhase?.title ?? 'Core Skills'}</span>
            <ChevronRight className="h-3 w-3" />
            <span className="text-white">{wp.code} · {wp.title}</span>
          </div>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 text-xs font-bold text-space-950">
            TT
          </div>
        </div>
      </header>

      <main className="px-6 py-6">
        {/* Waypoint title + status */}
        <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <span className="font-mono">{wp.code}</span>
              <span>·</span>
              <span>{wp.phase}</span>
            </div>
            <h1 className="text-3xl font-bold text-white">{wp.title}</h1>
            <p className="mt-2 text-sm text-slate-400">
              Est. completion: {wp.weeksLeft} weeks · {wp.hoursLeft} hrs remaining · {wp.progress}% complete
            </p>
          </div>
          <span className="rounded-full border border-amber-400/40 bg-amber-400/10 px-3 py-1 text-[10px] font-bold uppercase tracking-wide text-amber-300">
            In Progress
          </span>
        </div>

        {/* Progress bar */}
        <div className="mb-5 h-2 overflow-hidden rounded-full bg-white/5">
          <div className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-300" style={{ width: `${wp.progress}%` }} />
        </div>

        {/* Tabs */}
        <div className="mb-6 flex border-b border-white/[0.06]">
          {tabs.map((t) => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2.5 text-sm font-medium transition ${
                activeTab === t
                  ? 'border-b-2 border-cyan-400 text-white'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Two-column layout */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left: resource content */}
          <div className="space-y-5 lg:col-span-2">
            {/* Overview */}
            <section className="glass rounded-2xl p-5">
              <h2 className="mb-2 font-semibold text-white">Overview</h2>
              <p className="text-sm text-slate-400 leading-relaxed">{wp.description}</p>
            </section>

            {/* Resource manifest */}
            <section className="glass rounded-2xl p-5">
              <div className="mb-4 flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-cyan-300" />
                <h2 className="font-semibold text-white">Resource Manifest</h2>
              </div>
              <div className="space-y-2">
                {wp.resources.map((r, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-xl p-3 bg-white/[0.02]">
                    <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border ${
                      r.done ? 'border-cyan-400/50 bg-cyan-400/10' : 'border-white/10 bg-transparent'
                    }`}>
                      {r.done && <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${r.done ? 'text-slate-400' : 'text-white'}`}>{r.title}</p>
                      {r.type && <p className="text-[10px] text-slate-600">{r.type}</p>}
                    </div>
                    <span className="shrink-0 text-xs text-slate-500">{r.time}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => setMarkedDone(!markedDone)}
                className={`mt-5 flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition-all ${
                  markedDone
                    ? 'bg-emerald-400/20 text-emerald-300 border border-emerald-400/30'
                    : 'bg-amber-400 text-space-950 hover:bg-amber-300'
                }`}
              >
                {markedDone ? <CheckCircle2 className="h-4 w-4" /> : null}
                {markedDone ? 'Section Completed' : 'Mark Section Complete'}
              </button>
            </section>

            {/* Curated resources */}
            <section className="glass rounded-2xl p-5">
              <div className="mb-4 flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-cyan-300" />
                <h2 className="font-semibold text-white">Curated resources</h2>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {resources.slice(0, 4).map((r) => {
                  const Icon = resourceIcons[r.icon] ?? BookOpen;
                  return (
                    <div key={r.id} className="glass-hover group rounded-xl border border-white/5 bg-white/[0.02] p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-cyan-400/10 text-cyan-300">
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="flex items-center gap-1 text-amber-400">
                          <Star className="h-3 w-3 fill-current" />
                          <span className="text-xs font-semibold">{r.rating}</span>
                        </div>
                      </div>
                      <h3 className="mt-3 text-sm font-semibold leading-snug text-white">{r.title}</h3>
                      <p className="mt-1 text-[10px] text-slate-500">{r.type} · {r.provider}</p>
                      <div className="mt-3 flex items-center justify-between">
                        <div className="flex flex-wrap gap-1">
                          {r.tags.map((t) => (
                            <span key={t} className="rounded bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-400">{t}</span>
                          ))}
                        </div>
                        <span className="flex items-center gap-1 text-[10px] text-slate-500"><Clock className="h-3 w-3" />{r.estTime}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Phase waypoints */}
            <section className="glass rounded-2xl p-5">
              <div className="mb-4 flex items-center gap-2">
                <Award className="h-4 w-4 text-cyan-300" />
                <h2 className="font-semibold text-white">{activePhase?.title ?? 'Current Phase'} — Waypoints</h2>
              </div>
              <div className="space-y-2">
                {(activePhase?.waypoints ?? []).map((w) => (
                  <div key={w.id} className={`flex items-center gap-3 rounded-xl border p-3 ${
                    !w.done ? 'border-amber-400/20 bg-amber-400/[0.03]' : 'border-white/5 bg-white/[0.02]'
                  }`}>
                    <div className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${
                      w.done ? 'border-emerald-400 bg-emerald-400/20' : 'border-amber-400/50 bg-amber-400/10'
                    }`}>
                      {w.done && <CheckCircle2 className="h-3 w-3 text-emerald-400" />}
                      {!w.done && <div className="h-1.5 w-1.5 rounded-full bg-amber-400" />}
                    </div>
                    <span className={`flex-1 text-xs ${w.done ? 'text-slate-500 line-through' : 'text-slate-200'}`}>{w.title}</span>
                    <span className="text-[10px] text-slate-600 font-mono">{w.week}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Right: navigator quote + skill radar + phases */}
          <aside className="space-y-5">
            {/* Navigator's Log */}
            <section className="glass rounded-2xl p-5">
              <p className="mb-3 text-[10px] font-semibold uppercase tracking-widest text-cyan-400/70">Navigator's Log</p>
              <div className="rounded-xl border border-cyan-400/10 bg-cyan-400/[0.03] p-4">
                <p className="text-sm leading-relaxed text-slate-300 italic">
                  "{wp.navigatorNote}"
                </p>
              </div>
            </section>

            {/* Skill Radar */}
            <section className="glass rounded-2xl p-5">
              <div className="mb-3 flex items-center gap-2">
                <Target className="h-4 w-4 text-cyan-300" />
                <h2 className="font-semibold text-white">Skill Radar</h2>
              </div>
              <p className="mb-3 text-[10px] text-slate-500">Current vs Target · {profile.goalTitle}</p>

              <div className="flex justify-center">
                <svg width={size} height={size} className="overflow-visible">
                  {Array.from({ length: rings }).map((_, i) => {
                    const r = (maxR / rings) * (i + 1);
                    const pts = profile.radarSkills.map((_, j) => {
                      const a = -Math.PI / 2 + j * angleStep;
                      return `${center + r * Math.cos(a)},${center + r * Math.sin(a)}`;
                    }).join(' ');
                    return <polygon key={i} points={pts} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="1" />;
                  })}
                  {profile.radarSkills.map((_, i) => {
                    const a = -Math.PI / 2 + i * angleStep;
                    return (
                      <line key={i} x1={center} y1={center}
                        x2={center + maxR * Math.cos(a)} y2={center + maxR * Math.sin(a)}
                        stroke="rgba(255,255,255,0.05)" strokeWidth="1" />
                    );
                  })}
                  <polygon points={targetPts} fill="rgba(251,191,36,0.05)" stroke="rgba(251,191,36,0.3)" strokeWidth="1.5" strokeDasharray="4 3" />
                  <polygon points={polygonPts} fill="rgba(34,211,238,0.12)" stroke="#22d3ee" strokeWidth="2" />
                  {profile.radarSkills.map((s, i) => {
                    const p = pointFor(s.value, i);
                    return <circle key={s.skill} cx={p.x} cy={p.y} r="3" fill="#22d3ee" />;
                  })}
                  {profile.radarSkills.map((s, i) => {
                    const pos = labelPos(i);
                    return (
                      <text key={s.skill} x={pos.x} y={pos.y} textAnchor="middle" dominantBaseline="middle"
                        fontSize="9" fill="#64748b">{s.skill}</text>
                    );
                  })}
                </svg>
              </div>

              <div className="mt-3 flex items-center justify-end gap-4 text-[10px] text-slate-500">
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-cyan-400" /> Current</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-full border border-amber-400" style={{background:'rgba(251,191,36,0.2)'}} /> Target</span>
              </div>
            </section>

            {/* Phase progress */}
            <section className="glass rounded-2xl p-5">
              <h2 className="mb-3 font-semibold text-white">Phase Progress</h2>
              <div className="space-y-3">
                {profile.phases.map((p) => (
                  <div key={p.id}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className={`flex items-center gap-1.5 ${p.status === 'upcoming' ? 'text-slate-600' : 'text-slate-300'}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${
                          p.status === 'completed' ? 'bg-emerald-400' : p.status === 'active' ? 'bg-amber-400 animate-pulse' : 'bg-slate-700'
                        }`} />
                        {p.title}
                      </span>
                      <span className="text-slate-600">{p.progress}%</span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
                      <div className={`h-full rounded-full ${
                        p.status === 'completed' ? 'bg-emerald-400' : p.status === 'active' ? 'bg-amber-400' : 'bg-slate-700'
                      }`} style={{ width: `${p.progress}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <Link to="/dashboard" className="mt-4 flex items-center justify-center gap-1 text-xs text-cyan-300 hover:text-cyan-200">
                Back to Mission Control <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </section>
          </aside>
        </div>
      </main>
    </div>
  );
}
