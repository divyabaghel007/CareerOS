export type CareerGoal = {
  id: string;
  title: string;
  category: string;
  match: number;
  demand: 'Very High' | 'High' | 'Growing';
  avgSalary: string;
  icon: string;
};

export const careerGoals: CareerGoal[] = [
  { id: 'fullstack', title: 'Full-Stack Engineer', category: 'Engineering', match: 94, demand: 'Very High', avgSalary: '$128k', icon: 'Layers' },
  { id: 'ml', title: 'Machine Learning Engineer', category: 'AI/ML', match: 91, demand: 'Very High', avgSalary: '$156k', icon: 'BrainCircuit' },
  { id: 'devops', title: 'DevOps & Cloud Architect', category: 'Infrastructure', match: 88, demand: 'High', avgSalary: '$142k', icon: 'Server' },
  { id: 'sec', title: 'Security Engineer', category: 'Cybersecurity', match: 85, demand: 'Growing', avgSalary: '$134k', icon: 'ShieldCheck' },
  { id: 'data', title: 'Data Engineer', category: 'Data', match: 83, demand: 'Very High', avgSalary: '$131k', icon: 'Database' },
  { id: 'mobile', title: 'Mobile Engineer (iOS/Android)', category: 'Engineering', match: 79, demand: 'High', avgSalary: '$119k', icon: 'Smartphone' },
];

export type Skill = { id: string; name: string; category: string };

export const availableSkills: Skill[] = [
  { id: 'js', name: 'JavaScript', category: 'Languages' },
  { id: 'ts', name: 'TypeScript', category: 'Languages' },
  { id: 'py', name: 'Python', category: 'Languages' },
  { id: 'go', name: 'Go', category: 'Languages' },
  { id: 'rust', name: 'Rust', category: 'Languages' },
  { id: 'java', name: 'Java', category: 'Languages' },
  { id: 'react', name: 'React', category: 'Frontend' },
  { id: 'vue', name: 'Vue', category: 'Frontend' },
  { id: 'next', name: 'Next.js', category: 'Frontend' },
  { id: 'css', name: 'Tailwind/CSS', category: 'Frontend' },
  { id: 'node', name: 'Node.js', category: 'Backend' },
  { id: 'pg', name: 'PostgreSQL', category: 'Backend' },
  { id: 'mongodb', name: 'MongoDB', category: 'Backend' },
  { id: 'redis', name: 'Redis', category: 'Backend' },
  { id: 'graphql', name: 'GraphQL', category: 'Backend' },
  { id: 'docker', name: 'Docker', category: 'DevOps' },
  { id: 'k8s', name: 'Kubernetes', category: 'DevOps' },
  { id: 'aws', name: 'AWS', category: 'Cloud' },
  { id: 'gcp', name: 'GCP', category: 'Cloud' },
  { id: 'tf', name: 'Terraform', category: 'DevOps' },
  { id: 'ci', name: 'CI/CD', category: 'DevOps' },
  { id: 'ml', name: 'PyTorch', category: 'AI/ML' },
  { id: 'pandas', name: 'Pandas', category: 'AI/ML' },
  { id: 'spark', name: 'Spark', category: 'AI/ML' },
];

export const experienceLevels = [
  { id: 'beginner', title: 'Launch Cadet', desc: 'New to tech or switching careers', years: '0–1 years', icon: 'Rocket' },
  { id: 'junior', title: 'Orbital Engineer', desc: 'Building basics, ready to specialize', years: '1–3 years', icon: 'Satellite' },
  { id: 'mid', title: 'Mission Specialist', desc: 'Solid foundation, leveling up', years: '3–6 years', icon: 'Radar' },
  { id: 'senior', title: 'Flight Commander', desc: 'Experienced, targeting senior+ roles', years: '6+ years', icon: 'Compass' },
];

export const weeklyCommitments = [
  { hours: 5, label: '5 hrs', subtitle: 'Casual orbit' },
  { hours: 10, label: '10 hrs', subtitle: 'Steady thrust' },
  { hours: 15, label: '15 hrs', subtitle: 'Accelerated' },
  { hours: 20, label: '20 hrs', subtitle: 'Full burn' },
];

export type Phase = {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  weeks: string;
  status: 'completed' | 'active' | 'upcoming';
  progress: number;
  color: string;
  waypoints: { id: string; title: string; week: string; done: boolean }[];
};

export const roadmapPhases: Phase[] = [
  {
    id: 'p1',
    number: '01',
    title: 'Foundations & Core Systems',
    subtitle: 'Reinforce fundamentals before liftoff',
    weeks: 'Weeks 1–4',
    status: 'completed',
    progress: 100,
    color: 'emerald',
    waypoints: [
      { id: 'w1', title: 'Advanced TypeScript patterns', week: 'W1', done: true },
      { id: 'w2', title: 'React 18 internals & suspense', week: 'W2', done: true },
      { id: 'w3', title: 'System design primer', week: 'W3', done: true },
      { id: 'w4', title: 'Data structures deep-dive', week: 'W4', done: true },
    ],
  },
  {
    id: 'p2',
    number: '02',
    title: 'Backend & Distributed Systems',
    subtitle: 'Scale your knowledge of server-side engineering',
    weeks: 'Weeks 5–10',
    status: 'active',
    progress: 60,
    color: 'cyan',
    waypoints: [
      { id: 'w5', title: 'Node.js event loop mastery', week: 'W5', done: true },
      { id: 'w6', title: 'PostgreSQL performance tuning', week: 'W6', done: true },
      { id: 'w7', title: 'Microservices architecture', week: 'W7', done: true },
      { id: 'w8', title: 'Caching with Redis', week: 'W8', done: false },
      { id: 'w9', title: 'Kafka & event streaming', week: 'W9', done: false },
      { id: 'w10', title: 'API rate limiting & queues', week: 'W10', done: false },
    ],
  },
  {
    id: 'p3',
    number: '03',
    title: 'Cloud & DevOps Operations',
    subtitle: 'Deploy, observe, and scale like the pros',
    weeks: 'Weeks 11–16',
    status: 'upcoming',
    progress: 0,
    color: 'violet',
    waypoints: [
      { id: 'w11', title: 'Docker & containerization', week: 'W11', done: false },
      { id: 'w12', title: 'Kubernetes fundamentals', week: 'W12', done: false },
      { id: 'w13', title: 'AWS certification track', week: 'W13', done: false },
      { id: 'w14', title: 'Infrastructure as Code', week: 'W14', done: false },
      { id: 'w15', title: 'Observability stack', week: 'W15', done: false },
      { id: 'w16', title: 'CI/CD pipelines', week: 'W16', done: false },
    ],
  },
  {
    id: 'p4',
    number: '04',
    title: 'System Design & Interview Prep',
    subtitle: 'Bring it together for senior-level interviews',
    weeks: 'Weeks 17–22',
    status: 'upcoming',
    progress: 0,
    color: 'amber',
    waypoints: [
      { id: 'w17', title: 'Scalable system design', week: 'W17', done: false },
      { id: 'w18', title: 'Designing data-intensive apps', week: 'W18', done: false },
      { id: 'w19', title: 'Behavioral interview mastery', week: 'W19', done: false },
      { id: 'w20', title: 'Mock system design interviews', week: 'W20', done: false },
    ],
  },
];

export const kpiStats = [
  { label: 'Overall Progress', value: '38%', sub: '14 of 37 waypoints', icon: 'TrendingUp', trend: '+6% this week', color: 'cyan' },
  { label: 'Study Hours', value: '142', sub: 'of 300 hr target', icon: 'Clock', trend: '+12.5 hrs / wk', color: 'emerald' },
  { label: 'Streak', value: '23', sub: 'consecutive days', icon: 'Flame', trend: 'New record!', color: 'amber' },
  { label: 'Skill Score', value: '847', sub: '+120 since start', icon: 'Gauge', trend: 'Top 12% percentile', color: 'violet' },
];

export const weeklyGoals = [
  { id: 'g1', title: 'Complete Redis caching module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
  { id: 'g2', title: 'Ship 2 microservice endpoints', category: 'Project', est: '6 hrs', done: true, priority: 'high' },
  { id: 'g3', title: 'Read Designing Data-Intensive Apps Ch.5–6', category: 'Reading', est: '3 hrs', done: false, priority: 'medium' },
  { id: 'g4', title: 'Solve 5 system design problems', category: 'Practice', est: '5 hrs', done: false, priority: 'high' },
  { id: 'g5', title: 'Attend 1 tech meetup / talk', category: 'Network', est: '2 hrs', done: false, priority: 'low' },
];

export const radarSkills = [
  { skill: 'Frontend', value: 85 },
  { skill: 'Backend', value: 78 },
  { skill: 'DevOps', value: 62 },
  { skill: 'Cloud', value: 70 },
  { skill: 'System Design', value: 55 },
  { skill: 'Databases', value: 80 },
];

export const certifications = [
  {
    id: 'c1',
    name: 'AWS Solutions Architect — Associate',
    provider: 'Amazon Web Services',
    credentialId: 'AWS-SAA-2024-7821',
    estDuration: '80 hrs',
    difficulty: 'Intermediate',
    status: 'in-progress',
    progress: 64,
    cost: '$150',
    examDate: 'Aug 12, 2024',
    passRate: '72%',
    skillsCovered: ['EC2 & VPC', 'S3 & Storage', 'RDS & DynamoDB', 'IAM & Security', 'Lambda', 'CloudWatch'],
  },
  {
    id: 'c2',
    name: 'Certified Kubernetes Administrator',
    provider: 'CNCF',
    credentialId: 'CKA-2024-1142',
    estDuration: '60 hrs',
    difficulty: 'Advanced',
    status: 'planned',
    progress: 0,
    cost: '$395',
    examDate: 'Oct 2024',
    passRate: '68%',
    skillsCovered: ['Cluster Architecture', 'Workloads & Scheduling', 'Services & Networking', 'Storage', 'Troubleshooting'],
  },
];

export const resources = [
  { id: 'r1', title: 'AWS Certified Solutions Architect — Official Study Guide', type: 'Book', provider: 'AWS', estTime: '20 hrs', rating: 4.7, icon: 'BookOpen', tags: ['Foundational', 'Exam-ready'] },
  { id: 'r2', title: 'Kubernetes the Hard Way', type: 'Course', provider: 'Kelsey Hightower', estTime: '8 hrs', rating: 4.9, icon: 'Terminal', tags: ['Hands-on', 'Advanced'] },
  { id: 'r3', title: 'Designing Data-Intensive Applications', type: 'Book', provider: 'Martin Kleppmann', estTime: '25 hrs', rating: 4.8, icon: 'BookOpen', tags: ['Theory', 'Deep'] },
  { id: 'r4', title: 'System Design Interview Vol. 2', type: 'Book', provider: 'Alex Xu', estTime: '15 hrs', rating: 4.6, icon: 'Users', tags: ['Interview', 'Practical'] },
  { id: 'r5', title: 'Backend Engineering with Node.js', type: 'Video Series', provider: 'Frontend Masters', estTime: '12 hrs', rating: 4.5, icon: 'PlayCircle', tags: ['Project', 'Hands-on'] },
  { id: 'r6', title: 'Docker & Containers Deep Dive', type: 'Interactive Lab', provider: 'KodeKloud', estTime: '6 hrs', rating: 4.8, icon: 'Boxes', tags: ['Lab', 'Beginner'] },
];

export const progressHistory = [
  { week: 'W1', waypoints: 3, hours: 9.5 },
  { week: 'W2', waypoints: 4, hours: 11 },
  { week: 'W3', waypoints: 3, hours: 8.5 },
  { week: 'W4', waypoints: 4, hours: 12 },
  { week: 'W5', waypoints: 4, hours: 14.5 },
  { week: 'W6', waypoints: 3, hours: 13 },
  { week: 'W7', waypoints: 5, hours: 15.5 },
  { week: 'W8', waypoints: 2, hours: 10.5 },
  { week: 'W9', waypoints: 4, hours: 12.5 },
  { week: 'W10', waypoints: 3, hours: 14 },
  { week: 'W11', waypoints: 4, hours: 13.5 },
  { week: 'W12', waypoints: 2, hours: 11 },
];

export const skillGrowth = [
  { skill: 'Frontend', start: 60, current: 85, change: 25 },
  { skill: 'Backend', start: 45, current: 78, change: 33 },
  { skill: 'DevOps', start: 30, current: 62, change: 32 },
  { skill: 'Cloud', start: 35, current: 70, change: 35 },
  { skill: 'System Design', start: 25, current: 55, change: 30 },
  { skill: 'Databases', start: 50, current: 80, change: 30 },
];

export const badges = [
  { id: 'b1', name: 'First Steps', desc: 'Completed your first waypoint', icon: 'Rocket', earned: true, date: 'May 4', rarity: 'common' },
  { id: 'b2', name: 'Week Warrior', desc: '7-day study streak', icon: 'Calendar', earned: true, date: 'May 11', rarity: 'common' },
  { id: 'b3', name: 'Foundation Master', desc: 'Finished Phase 1', icon: 'LayoutGrid', earned: true, date: 'Jun 1', rarity: 'rare' },
  { id: 'b4', name: 'Deep Diver', desc: '100+ study hours logged', icon: 'Waves', earned: true, date: 'Jun 18', rarity: 'rare' },
  { id: 'b5', name: 'Streak Commander', desc: '20-day study streak', icon: 'Flame', earned: true, date: 'Jun 22', rarity: 'epic' },
  { id: 'b6', name: 'Certified', desc: 'Earn a certification', icon: 'Award', earned: false, date: null, rarity: 'epic' },
  { id: 'b7', name: 'Halfway There', desc: '50% roadmap completion', icon: 'Target', earned: false, date: null, rarity: 'rare' },
  { id: 'b8', name: 'Mission Complete', desc: 'Finish the full roadmap', icon: 'Trophy', earned: false, date: null, rarity: 'legendary' },
];

export const learningStats = [
  { label: 'Total Study Hours', value: '142', unit: 'hrs', sub: 'of 300 goal', icon: 'Clock' },
  { label: 'Waypoints Cleared', value: '14', unit: '/37', sub: '38% complete', icon: 'Flag' },
  { label: 'Projects Shipped', value: '6', unit: '', sub: '2 this month', icon: 'Package' },
  { label: 'Avg Session', value: '2.3', unit: 'hrs', sub: 'per day', icon: 'Timer' },
  { label: 'Lessons Done', value: '89', unit: '', sub: 'across 4 sources', icon: 'BookOpen' },
  { label: 'Problems Solved', value: '124', unit: '', sub: 'algo & system design', icon: 'CheckCircle2' },
];

export const userProfile = {
  name: 'Alex Rivera',
  title: 'Mission: Full-Stack Engineer',
  level: 7,
  rank: 'Mission Specialist',
  rankPercentile: 'Top 12%',
  joined: 'May 2024',
  xp: 8470,
  xpToNext: 10000,
  weeklyAvgHours: 12.5,
  targetCompletion: 'Nov 2024',
  avatarInitials: 'AR',
  nextBadge: 'Certified',
  nextBadgeProgress: 64,
};

export const upcomingMilestones = [
  { id: 'm1', title: 'Complete Phase 2', due: 'In 4 weeks', progress: 60, icon: 'Satellite' },
  { id: 'm2', title: 'AWS SAA Certification', due: 'Aug 12, 2024', progress: 64, icon: 'Award' },
  { id: 'm3', title: 'Begin Phase 3: Cloud', due: 'In 6 weeks', progress: 0, icon: 'Cloud' },
];
