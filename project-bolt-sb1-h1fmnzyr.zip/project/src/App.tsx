import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { CareerProvider } from './context/CareerContext';
import LandingPage from './pages/LandingPage';
import AssessmentPage from './pages/AssessmentPage';
import DashboardPage from './pages/DashboardPage';
import WaypointPage from './pages/WaypointPage';
import FlightLogPage from './pages/FlightLogPage';
import DashboardLayout from './components/DashboardLayout';

export default function App() {
  return (
    <CareerProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/assessment" element={<AssessmentPage />} />
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/waypoint" element={<WaypointPage />} />
            <Route path="/flight-log" element={<FlightLogPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </CareerProvider>
  );
}
