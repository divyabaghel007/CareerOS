import { createContext, useContext, useState, ReactNode } from 'react';

export type CareerProfile = {
  goalTitle: string;          // e.g. "Data Analyst"
  currentRole: string;        // e.g. "Marketing Coordinator"
  targetRole: string;         // e.g. "Senior Data Analyst"
  category: string;
  avgSalary: string;
  demand: string;
  timelineMonths: number;
  skills: string[];           // key skills for this career
  phases: CareerPhase[];
  weeklyGoals: CareerWeeklyGoal[];
  currentWaypoint: CareerWaypoint;
  radarSkills: { skill: string; value: number; target: number }[];
  navigatorNotes: string[];   // per-step messages in assessment
};

export type CareerPhase = {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  weeks: string;
  status: 'completed' | 'active' | 'upcoming';
  progress: number;
  waypoints: { id: string; title: string; week: string; done: boolean }[];
};

export type CareerWeeklyGoal = {
  id: string;
  title: string;
  category: string;
  est: string;
  done: boolean;
  priority: 'high' | 'medium' | 'low';
};

export type CareerWaypoint = {
  id: string;
  code: string;
  phase: string;
  title: string;
  description: string;
  progress: number;
  hoursLeft: number;
  weeksLeft: number;
  resources: WaypointResource[];
  navigatorNote: string;
};

export type WaypointResource = {
  title: string;
  type: string;
  time: string;
  done: boolean;
};

type CareerContextValue = {
  goalInput: string;            // raw string the user typed
  setGoalInput: (g: string) => void;
  profile: CareerProfile;
  experience: string;
  setExperience: (e: string) => void;
  weeklyHours: number;
  setWeeklyHours: (h: number) => void;
  selectedSkills: string[];
  setSelectedSkills: (s: string[]) => void;
};

const CareerContext = createContext<CareerContextValue | null>(null);

export function useCareer() {
  const ctx = useContext(CareerContext);
  if (!ctx) throw new Error('useCareer must be used inside CareerProvider');
  return ctx;
}

// ─── Career profile lookup ────────────────────────────────────────────────────

function buildProfile(goal: string): CareerProfile {
  const normalized = goal.trim().toLowerCase();

  if (normalized.includes('data analyst') || normalized.includes('data analysis')) {
    return dataAnalystProfile;
  }
  if (normalized.includes('data scientist') || normalized.includes('data science')) {
    return dataScientistProfile;
  }
  if (normalized.includes('product manager') || normalized.includes('pm')) {
    return productManagerProfile;
  }
  if (normalized.includes('full stack') || normalized.includes('fullstack') || normalized.includes('full-stack') || normalized.includes('software engineer') || normalized.includes('web developer')) {
    return fullStackProfile;
  }
  if (normalized.includes('ux') || normalized.includes('ui') || normalized.includes('designer') || normalized.includes('design')) {
    return uxDesignerProfile;
  }
  if (normalized.includes('devops') || normalized.includes('cloud') || normalized.includes('sre') || normalized.includes('platform')) {
    return devOpsProfile;
  }
  if (normalized.includes('machine learning') || normalized.includes('ml engineer') || normalized.includes('ai engineer')) {
    return mlEngineerProfile;
  }
  if (normalized.includes('security') || normalized.includes('cybersecurity') || normalized.includes('infosec')) {
    return securityProfile;
  }
  // Default: use the goal text itself with a generic profile
  return genericProfile(goal.trim() || 'Senior Professional');
}

// ─── Data Analyst ─────────────────────────────────────────────────────────────
const dataAnalystProfile: CareerProfile = {
  goalTitle: 'Data Analyst',
  currentRole: 'Junior Analyst',
  targetRole: 'Senior Data Analyst',
  category: 'Data & Analytics',
  avgSalary: '$95k',
  demand: 'Very High',
  timelineMonths: 8,
  skills: ['SQL', 'Python', 'Tableau', 'Excel', 'Statistics', 'Data Visualization'],
  navigatorNotes: [
    'Strong SQL background detected. I\'ll front-load advanced query optimization and window functions — these are the skills that separate juniors from seniors in data roles.',
    'Your experience level shapes how quickly we move through statistical fundamentals. I\'ll keep the math intuitive before diving into inferential stats.',
    'With your weekly commitment locked in, I\'ll structure each waypoint to fit naturally into your schedule — no burnout, steady momentum.',
  ],
  radarSkills: [
    { skill: 'SQL', value: 80, target: 95 },
    { skill: 'Python', value: 55, target: 85 },
    { skill: 'Statistics', value: 50, target: 80 },
    { skill: 'Visualization', value: 70, target: 90 },
    { skill: 'Business Intel', value: 65, target: 85 },
    { skill: 'Communication', value: 75, target: 90 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'SQL & Data Foundations', subtitle: 'Master querying and data manipulation',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'Advanced SQL: Window Functions & CTEs', week: 'W1', done: true },
        { id: 'w2', title: 'Database design & normalization', week: 'W2', done: true },
        { id: 'w3', title: 'Data cleaning with Pandas', week: 'W3', done: true },
        { id: 'w4', title: 'Excel pivot tables & power query', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Analytics & Visualization', subtitle: 'Tell stories with data',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Tableau fundamentals', week: 'W5', done: true },
        { id: 'w6', title: 'Advanced SQL Certification', week: 'W6', done: false },
        { id: 'w7', title: 'Statistics for data analysts', week: 'W7', done: false },
        { id: 'w8', title: 'Google Data Studio', week: 'W8', done: false },
        { id: 'w9', title: 'A/B testing & experiment design', week: 'W9', done: false },
        { id: 'w10', title: 'Build: Sales dashboard portfolio project', week: 'W10', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Python for Analytics', subtitle: 'Automate and scale your analysis',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w11', title: 'Python data analysis with Pandas', week: 'W11', done: false },
        { id: 'w12', title: 'Data visualization with Matplotlib/Seaborn', week: 'W12', done: false },
        { id: 'w13', title: 'Automating reports with Python', week: 'W13', done: false },
        { id: 'w14', title: 'Working with APIs & JSON data', week: 'W14', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'Advanced Analytics & Portfolio', subtitle: 'Land the senior role',
      weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w15', title: 'Predictive analytics fundamentals', week: 'W17', done: false },
        { id: 'w16', title: 'Stakeholder presentations & storytelling', week: 'W19', done: false },
        { id: 'w17', title: 'Portfolio: 3 end-to-end analysis projects', week: 'W21', done: false },
        { id: 'w18', title: 'Mock interviews: analytics case studies', week: 'W22', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Complete Tableau dashboard module', category: 'Learning', est: '3 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Write SQL report for sales data', category: 'Project', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "Storytelling with Data" Ch.4–5', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Solve 5 HackerRank SQL challenges', category: 'Practice', est: '3 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Network with 2 data analysts on LinkedIn', category: 'Network', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw1', code: 'WP-06', phase: 'Analytics & Visualization',
    title: 'Advanced SQL Certification',
    description: 'This waypoint builds the analytical backbone every senior data analyst leans on: writing performant joins, structuring queries for dashboards, and translating stakeholder questions into SQL. Navigator AI selected this module based on a gap between your current and target skill profile.',
    progress: 40, hoursLeft: 12, weeksLeft: 3,
    navigatorNote: 'You tend to skip optimization steps under deadline. Spend extra time on this section — it shows up again in your portfolio project at WP-10.',
    resources: [
      { title: 'Joins, Subqueries & CTEs', type: 'Substack · Video', time: '2h 10m', done: true },
      { title: 'Query Optimization Field Guide', type: 'Interact Xtra · Article', time: '35m', done: true },
      { title: 'Build: Revenue Dashboard Query Set', type: 'Project', time: '4h', done: false },
      { title: 'Window Functions Deep Dive', type: 'Substack · Video', time: '2h 45m', done: false },
    ],
  },
};

// ─── Data Scientist ────────────────────────────────────────────────────────────
const dataScientistProfile: CareerProfile = {
  goalTitle: 'Data Scientist',
  currentRole: 'Data Analyst',
  targetRole: 'Senior Data Scientist',
  category: 'AI/ML & Data',
  avgSalary: '$138k',
  demand: 'Very High',
  timelineMonths: 12,
  skills: ['Python', 'Machine Learning', 'Statistics', 'SQL', 'TensorFlow', 'Feature Engineering'],
  navigatorNotes: [
    'Solid Python foundation detected. I\'ll weight your roadmap toward ML modeling and experiment design — the core skillset that separates data scientists from analysts.',
    'Your experience level helps me calibrate how deep we go into statistical theory before moving to applied ML. I\'ll keep theory tied to real datasets.',
    'With your pace set, I\'ll structure each module to include both theory and a hands-on project so concepts stick — not just conceptual knowledge.',
  ],
  radarSkills: [
    { skill: 'Python', value: 75, target: 95 },
    { skill: 'Statistics', value: 60, target: 90 },
    { skill: 'ML Models', value: 45, target: 88 },
    { skill: 'SQL', value: 80, target: 85 },
    { skill: 'Data Wrangling', value: 70, target: 90 },
    { skill: 'Experimentation', value: 40, target: 85 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'Python & Statistics Foundations', subtitle: 'Build the mathematical and coding bedrock',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'NumPy & Pandas mastery', week: 'W1', done: true },
        { id: 'w2', title: 'Probability & distributions', week: 'W2', done: true },
        { id: 'w3', title: 'Inferential statistics & hypothesis testing', week: 'W3', done: true },
        { id: 'w4', title: 'Exploratory data analysis workflow', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Machine Learning Core', subtitle: 'Supervised and unsupervised learning',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Regression & classification models', week: 'W5', done: true },
        { id: 'w6', title: 'Feature engineering & selection', week: 'W6', done: false },
        { id: 'w7', title: 'Model evaluation & cross-validation', week: 'W7', done: false },
        { id: 'w8', title: 'Ensemble methods: Random Forest & XGBoost', week: 'W8', done: false },
        { id: 'w9', title: 'Clustering & dimensionality reduction', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Deep Learning & NLP', subtitle: 'Neural networks and language models',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w10', title: 'Neural network fundamentals with TensorFlow', week: 'W11', done: false },
        { id: 'w11', title: 'CNNs for image classification', week: 'W12', done: false },
        { id: 'w12', title: 'NLP with Hugging Face Transformers', week: 'W14', done: false },
        { id: 'w13', title: 'MLOps: experiment tracking with MLflow', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'Applied Science & Portfolio', subtitle: 'Ship production models, land the role',
      weeks: 'Weeks 17–24', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w14', title: 'Capstone: end-to-end ML pipeline', week: 'W17', done: false },
        { id: 'w15', title: 'A/B testing & experimentation design', week: 'W20', done: false },
        { id: 'w16', title: 'Technical interview prep: ML system design', week: 'W23', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Finish Feature Engineering module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Kaggle competition submission', category: 'Project', est: '5 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "Hands-On ML" Ch.7–8', category: 'Reading', est: '3 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Implement XGBoost from scratch', category: 'Practice', est: '4 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Review 3 data science job postings', category: 'Career', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw2', code: 'WP-06', phase: 'Machine Learning Core',
    title: 'Feature Engineering & Selection',
    description: 'Feature engineering is often what separates a mediocre model from a production-ready one. This waypoint covers transformations, encoding strategies, and selection methods that will directly impact your Kaggle scores and interview performance.',
    progress: 40, hoursLeft: 9, weeksLeft: 2,
    navigatorNote: 'You tend to jump to modeling before cleaning features. Spend extra time here — interviewers routinely ask about your feature engineering decisions.',
    resources: [
      { title: 'Feature Engineering for Machine Learning (Udemy)', type: 'Course · Video', time: '6h', done: true },
      { title: 'Categorical Encoding Strategies', type: 'Towards Data Science · Article', time: '45m', done: false },
      { title: 'Build: Titanic feature pipeline', type: 'Project', time: '3h', done: false },
      { title: 'Recursive Feature Elimination deep dive', type: 'Notebook · Interactive', time: '1h 30m', done: false },
    ],
  },
};

// ─── Product Manager ──────────────────────────────────────────────────────────
const productManagerProfile: CareerProfile = {
  goalTitle: 'Product Manager',
  currentRole: 'Marketing Coordinator',
  targetRole: 'Senior Product Manager',
  category: 'Product',
  avgSalary: '$128k',
  demand: 'High',
  timelineMonths: 10,
  skills: ['Product Strategy', 'Roadmapping', 'Stakeholder Management', 'Data Analysis', 'SQL', 'User Research'],
  navigatorNotes: [
    'Cross-functional background detected. I\'ll weight your roadmap toward product discovery and metrics — these are where PM candidates most commonly fall short in interviews.',
    'Your experience level helps me calibrate the balance between PM theory and hands-on case study practice. I\'ll keep it applied throughout.',
    'With your schedule set, I\'ll pace waypoints so each week produces a deliverable you can add to your PM portfolio.',
  ],
  radarSkills: [
    { skill: 'Strategy', value: 60, target: 90 },
    { skill: 'Data/SQL', value: 55, target: 80 },
    { skill: 'User Research', value: 65, target: 85 },
    { skill: 'Stakeholders', value: 75, target: 90 },
    { skill: 'Roadmapping', value: 50, target: 88 },
    { skill: 'Communication', value: 80, target: 92 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'PM Foundations', subtitle: 'Product thinking and discovery',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'Product discovery & user interviews', week: 'W1', done: true },
        { id: 'w2', title: 'Writing PRDs and user stories', week: 'W2', done: true },
        { id: 'w3', title: 'Prioritization frameworks: RICE, MoSCoW', week: 'W3', done: true },
        { id: 'w4', title: 'Agile & sprint planning basics', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Data & Metrics', subtitle: 'Make decisions with confidence',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'SQL for PMs: dashboards and funnels', week: 'W5', done: true },
        { id: 'w6', title: 'Defining north star metrics & OKRs', week: 'W6', done: false },
        { id: 'w7', title: 'A/B testing for product decisions', week: 'W7', done: false },
        { id: 'w8', title: 'Product analytics with Amplitude/Mixpanel', week: 'W8', done: false },
        { id: 'w9', title: 'Build: metrics dashboard for mock product', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Roadmap & Strategy', subtitle: 'Own the product vision',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w10', title: 'Competitive analysis frameworks', week: 'W11', done: false },
        { id: 'w11', title: 'Product strategy & positioning', week: 'W12', done: false },
        { id: 'w12', title: 'Roadmap communication with stakeholders', week: 'W14', done: false },
        { id: 'w13', title: 'Go-to-market planning', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'Interview Prep & Portfolio', subtitle: 'Land the PM role',
      weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w14', title: 'PM case study mastery', week: 'W17', done: false },
        { id: 'w15', title: 'Behavioral interview: leadership & conflict', week: 'W19', done: false },
        { id: 'w16', title: 'Portfolio: 3 product case studies', week: 'W21', done: false },
        { id: 'w17', title: 'Mock interviews: product sense + metrics', week: 'W22', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Write PRD for mock checkout feature', category: 'Project', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'SQL: build funnel analysis query', category: 'Learning', est: '3 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "Inspired" Ch.6–8', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Practice 3 product sense questions', category: 'Practice', est: '3 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Attend 1 PM Slack community AMA', category: 'Network', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw3', code: 'WP-06', phase: 'Data & Metrics',
    title: 'Defining North Star Metrics & OKRs',
    description: 'Every strong PM knows what to measure and why. This waypoint covers selecting north star metrics, building OKR trees, and avoiding vanity metrics that mislead teams. Navigator AI chose this because metric fluency is tested in virtually every senior PM interview.',
    progress: 40, hoursLeft: 8, weeksLeft: 2,
    navigatorNote: 'PMs who can\'t talk metrics in interviews consistently lose to candidates who can. Spend extra time here — every case study question will ultimately come back to measurement.',
    resources: [
      { title: 'Metrics that Matter (Reforge)', type: 'Course · Video', time: '3h', done: true },
      { title: 'OKR Framework: Google\'s approach', type: 'Article', time: '45m', done: false },
      { title: 'Build: OKR tree for a mock SaaS product', type: 'Project', time: '2h', done: false },
      { title: 'Mock: Define the north star for Spotify', type: 'Practice', time: '1h 30m', done: false },
    ],
  },
};

// ─── Full Stack Engineer ───────────────────────────────────────────────────────
const fullStackProfile: CareerProfile = {
  goalTitle: 'Full-Stack Engineer',
  currentRole: 'Junior Developer',
  targetRole: 'Senior Full-Stack Engineer',
  category: 'Engineering',
  avgSalary: '$128k',
  demand: 'Very High',
  timelineMonths: 9,
  skills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'Docker', 'System Design'],
  navigatorNotes: [
    'Solid frontend foundation detected. I\'ll weight your roadmap toward backend systems and infrastructure — the skills that unlock senior full-stack roles.',
    'Your experience level calibrates how fast we move through each system. I\'ll balance depth with breadth to ensure you can confidently talk about every layer of the stack.',
    'With your weekly hours set, I\'ll structure each waypoint so you ship something real — not just follow tutorials.',
  ],
  radarSkills: [
    { skill: 'Frontend', value: 85, target: 95 },
    { skill: 'Backend', value: 62, target: 90 },
    { skill: 'Databases', value: 70, target: 88 },
    { skill: 'DevOps', value: 40, target: 75 },
    { skill: 'System Design', value: 50, target: 85 },
    { skill: 'Testing', value: 55, target: 80 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'Foundations & Core Systems', subtitle: 'Reinforce fundamentals before liftoff',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'Advanced TypeScript patterns', week: 'W1', done: true },
        { id: 'w2', title: 'React 18 internals & suspense', week: 'W2', done: true },
        { id: 'w3', title: 'System design primer', week: 'W3', done: true },
        { id: 'w4', title: 'Data structures deep-dive', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Backend & Distributed Systems', subtitle: 'Scale your server-side knowledge',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Node.js event loop mastery', week: 'W5', done: true },
        { id: 'w6', title: 'PostgreSQL performance tuning', week: 'W6', done: false },
        { id: 'w7', title: 'REST vs GraphQL API design', week: 'W7', done: false },
        { id: 'w8', title: 'Caching with Redis', week: 'W8', done: false },
        { id: 'w9', title: 'Microservices architecture', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Cloud & DevOps', subtitle: 'Deploy, observe, and scale',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w10', title: 'Docker & containerization', week: 'W11', done: false },
        { id: 'w11', title: 'AWS core services (EC2, S3, RDS)', week: 'W12', done: false },
        { id: 'w12', title: 'CI/CD pipelines with GitHub Actions', week: 'W14', done: false },
        { id: 'w13', title: 'Kubernetes fundamentals', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'System Design & Interview Prep', subtitle: 'Senior-level interviews',
      weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w14', title: 'Scalable system design patterns', week: 'W17', done: false },
        { id: 'w15', title: 'Behavioral interview mastery', week: 'W19', done: false },
        { id: 'w16', title: 'Mock system design interviews', week: 'W21', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Complete PostgreSQL indexing module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Ship 2 REST API endpoints with tests', category: 'Project', est: '5 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "Designing Data-Intensive Apps" Ch.5', category: 'Reading', est: '3 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Solve 5 LeetCode medium problems', category: 'Practice', est: '4 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Contribute to 1 open-source issue', category: 'Network', est: '2 hrs', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw4', code: 'WP-06', phase: 'Backend & Distributed Systems',
    title: 'PostgreSQL Performance Tuning',
    description: 'This waypoint covers writing performant queries, designing proper indexes, and understanding query planners. Navigator AI selected this because database knowledge is the most common gap between junior and senior full-stack engineers.',
    progress: 40, hoursLeft: 10, weeksLeft: 2,
    navigatorNote: 'Most engineers skip EXPLAIN ANALYZE until production fires happen. Spend time here — interviewers at senior levels expect you to talk about query performance fluently.',
    resources: [
      { title: 'PostgreSQL: Up and Running (O\'Reilly)', type: 'Book · Reading', time: '4h', done: true },
      { title: 'Indexing Strategies for Postgres', type: 'Article', time: '45m', done: true },
      { title: 'Build: optimize a slow e-commerce query', type: 'Project', time: '3h', done: false },
      { title: 'EXPLAIN ANALYZE deep dive', type: 'Video', time: '1h 20m', done: false },
    ],
  },
};

// ─── UX Designer ──────────────────────────────────────────────────────────────
const uxDesignerProfile: CareerProfile = {
  goalTitle: 'UX/UI Designer',
  currentRole: 'Graphic Designer',
  targetRole: 'Senior UX Designer',
  category: 'Design',
  avgSalary: '$108k',
  demand: 'High',
  timelineMonths: 8,
  skills: ['Figma', 'User Research', 'Prototyping', 'Interaction Design', 'Usability Testing', 'Design Systems'],
  navigatorNotes: [
    'Visual design background detected. I\'ll weight your roadmap toward UX research and interaction design — the skills that distinguish UX from pure visual roles.',
    'Your experience level helps calibrate how much theory versus portfolio work we prioritize. I\'ll make sure each waypoint produces a case study artifact.',
    'With your pace set, I\'ll ensure every module ends with a Figma deliverable you can include in your portfolio.',
  ],
  radarSkills: [
    { skill: 'Visual Design', value: 85, target: 90 },
    { skill: 'User Research', value: 45, target: 85 },
    { skill: 'Prototyping', value: 65, target: 90 },
    { skill: 'Interaction', value: 55, target: 85 },
    { skill: 'Accessibility', value: 40, target: 80 },
    { skill: 'Design Systems', value: 50, target: 88 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'UX Research Foundations', subtitle: 'Understand users before designing for them',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'User interviews & affinity mapping', week: 'W1', done: true },
        { id: 'w2', title: 'Personas, jobs-to-be-done & journey maps', week: 'W2', done: true },
        { id: 'w3', title: 'Heuristic evaluation & competitive audit', week: 'W3', done: true },
        { id: 'w4', title: 'Usability testing fundamentals', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Interaction & Prototyping', subtitle: 'Design flows that convert',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Figma advanced: auto-layout & variants', week: 'W5', done: true },
        { id: 'w6', title: 'Interaction design patterns', week: 'W6', done: false },
        { id: 'w7', title: 'High-fidelity prototyping in Figma', week: 'W7', done: false },
        { id: 'w8', title: 'Micro-interactions & motion design', week: 'W8', done: false },
        { id: 'w9', title: 'Case study: redesign a broken flow', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Design Systems & Accessibility', subtitle: 'Build at scale',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w10', title: 'Design tokens & component libraries', week: 'W11', done: false },
        { id: 'w11', title: 'WCAG 2.1 accessibility standards', week: 'W12', done: false },
        { id: 'w12', title: 'Collaborating with engineers via Figma', week: 'W14', done: false },
        { id: 'w13', title: 'Build: personal design system', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'Portfolio & Job Search', subtitle: 'Land the senior UX role',
      weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w14', title: 'Portfolio: 3 polished case studies', week: 'W17', done: false },
        { id: 'w15', title: 'UX interview: whiteboard challenges', week: 'W19', done: false },
        { id: 'w16', title: 'Salary negotiation & offer evaluation', week: 'W22', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Finish Figma advanced auto-layout module', category: 'Learning', est: '3 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Complete usability test for portfolio project', category: 'Project', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "The Design of Everyday Things" Ch.3–4', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Redesign 1 app screen for accessibility', category: 'Practice', est: '3 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Get feedback from 2 designers on Dribbble', category: 'Network', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw5', code: 'WP-06', phase: 'Interaction & Prototyping',
    title: 'Interaction Design Patterns',
    description: 'Understanding established interaction patterns — navigation, forms, state management in UI — lets you design with confidence and communicate with engineers effectively. Navigator AI identified this gap after reviewing your portfolio samples.',
    progress: 40, hoursLeft: 7, weeksLeft: 2,
    navigatorNote: 'Your visual work is strong, but interviewers will ask you to explain your interaction decisions. Document your "why" for every pattern you use in your prototypes.',
    resources: [
      { title: 'UI Patterns for Web Applications', type: 'Book · Reading', time: '3h', done: true },
      { title: 'Figma Interaction Playground', type: 'Interactive · Lab', time: '2h', done: false },
      { title: 'Build: interactive prototype for onboarding flow', type: 'Project', time: '3h', done: false },
      { title: 'Teardown: Stripe dashboard UX analysis', type: 'Article', time: '45m', done: false },
    ],
  },
};

// ─── DevOps Engineer ──────────────────────────────────────────────────────────
const devOpsProfile: CareerProfile = {
  goalTitle: 'DevOps Engineer',
  currentRole: 'Systems Administrator',
  targetRole: 'Senior DevOps / Platform Engineer',
  category: 'Infrastructure',
  avgSalary: '$142k',
  demand: 'Very High',
  timelineMonths: 10,
  skills: ['Docker', 'Kubernetes', 'Terraform', 'AWS', 'CI/CD', 'Observability'],
  navigatorNotes: [
    'Linux and scripting background detected. I\'ll weight your roadmap toward Kubernetes and cloud-native patterns — where the senior DevOps market is headed.',
    'Your experience with infrastructure helps me skip the basics and get you to container orchestration and IaC faster.',
    'With your schedule locked in, I\'ll ensure each waypoint delivers a working infrastructure artifact — Terraform modules, Helm charts, pipeline configs.',
  ],
  radarSkills: [
    { skill: 'Docker', value: 75, target: 95 },
    { skill: 'Kubernetes', value: 45, target: 90 },
    { skill: 'Terraform', value: 50, target: 88 },
    { skill: 'AWS', value: 60, target: 90 },
    { skill: 'Observability', value: 40, target: 82 },
    { skill: 'Security', value: 55, target: 80 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'Containers & Docker', subtitle: 'Master containerization fundamentals',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'Docker deep dive: images & layers', week: 'W1', done: true },
        { id: 'w2', title: 'Docker Compose for local dev', week: 'W2', done: true },
        { id: 'w3', title: 'Container security best practices', week: 'W3', done: true },
        { id: 'w4', title: 'Build: containerize a Node.js app', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Kubernetes & Orchestration', subtitle: 'Run containers at scale',
      weeks: 'Weeks 5–10', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Kubernetes architecture & core objects', week: 'W5', done: true },
        { id: 'w6', title: 'Deployments, services & ingress', week: 'W6', done: false },
        { id: 'w7', title: 'Helm charts & package management', week: 'W7', done: false },
        { id: 'w8', title: 'CKA certification track', week: 'W8', done: false },
        { id: 'w9', title: 'Build: deploy microservices to k8s', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Cloud & Infrastructure as Code', subtitle: 'AWS + Terraform',
      weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w10', title: 'AWS core: VPC, EC2, RDS, S3', week: 'W11', done: false },
        { id: 'w11', title: 'Terraform fundamentals', week: 'W12', done: false },
        { id: 'w12', title: 'AWS Solutions Architect certification track', week: 'W14', done: false },
        { id: 'w13', title: 'Build: multi-region infrastructure with Terraform', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'CI/CD & Observability', subtitle: 'Ship with confidence',
      weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w14', title: 'GitHub Actions & GitLab CI pipelines', week: 'W17', done: false },
        { id: 'w15', title: 'Prometheus, Grafana & alerting', week: 'W19', done: false },
        { id: 'w16', title: 'Distributed tracing with OpenTelemetry', week: 'W21', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Finish k8s Deployments & Services module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Deploy a 3-tier app to local k8s cluster', category: 'Project', est: '6 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read k8s docs: networking in depth', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Complete 3 CKA practice labs', category: 'Practice', est: '4 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Join #devops on local tech Slack', category: 'Network', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw6', code: 'WP-06', phase: 'Kubernetes & Orchestration',
    title: 'Deployments, Services & Ingress',
    description: 'Deployments and Services are the bread and butter of running production workloads in Kubernetes. This waypoint ensures you can configure rolling updates, health checks, and external traffic routing without referencing documentation.',
    progress: 40, hoursLeft: 11, weeksLeft: 3,
    navigatorNote: 'Most candidates trip on networking in k8s interviews. Spend extra time on Service types and Ingress controllers — these questions appear in nearly every senior DevOps interview.',
    resources: [
      { title: 'Kubernetes in Action (Manning)', type: 'Book · Reading', time: '5h', done: true },
      { title: 'k8s Deployments: rolling updates & rollbacks', type: 'Video', time: '1h 30m', done: false },
      { title: 'Build: blue-green deployment pipeline', type: 'Project', time: '4h', done: false },
      { title: 'NGINX Ingress controller setup', type: 'Lab · Interactive', time: '2h', done: false },
    ],
  },
};

// ─── ML Engineer ──────────────────────────────────────────────────────────────
const mlEngineerProfile: CareerProfile = {
  goalTitle: 'ML Engineer',
  currentRole: 'Software Engineer',
  targetRole: 'Senior Machine Learning Engineer',
  category: 'AI/ML',
  avgSalary: '$156k',
  demand: 'Very High',
  timelineMonths: 12,
  skills: ['Python', 'PyTorch', 'MLOps', 'Feature Engineering', 'Model Deployment', 'Distributed Training'],
  navigatorNotes: [
    'Engineering background detected. I\'ll weight your roadmap toward MLOps and production ML — the skills most software engineers lack when transitioning into ML roles.',
    'Your coding experience accelerates the ML fundamentals track. We\'ll move faster through algorithm theory and spend more time on model deployment and pipelines.',
    'With your pace set, every waypoint will include a model you can point to in interviews — from training to serving.',
  ],
  radarSkills: [
    { skill: 'Python/PyTorch', value: 70, target: 95 },
    { skill: 'ML Theory', value: 55, target: 88 },
    { skill: 'MLOps', value: 30, target: 85 },
    { skill: 'Feature Eng.', value: 50, target: 90 },
    { skill: 'Distributed', value: 25, target: 75 },
    { skill: 'Deployment', value: 40, target: 88 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'ML Foundations & PyTorch', subtitle: 'Build the core ML intuition',
      weeks: 'Weeks 1–5', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'Linear algebra & calculus for ML', week: 'W1', done: true },
        { id: 'w2', title: 'PyTorch fundamentals & autograd', week: 'W2', done: true },
        { id: 'w3', title: 'Training loops & model evaluation', week: 'W3', done: true },
        { id: 'w4', title: 'CNNs & image classification', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Production ML & MLOps', subtitle: 'Ship models that actually run',
      weeks: 'Weeks 6–12', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'MLflow: experiment tracking', week: 'W6', done: true },
        { id: 'w6', title: 'Feature stores & data pipelines', week: 'W7', done: false },
        { id: 'w7', title: 'Model serving with FastAPI & TorchServe', week: 'W8', done: false },
        { id: 'w8', title: 'Docker + Kubernetes for ML workloads', week: 'W10', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Advanced Models & Transformers', subtitle: 'LLMs and beyond',
      weeks: 'Weeks 13–18', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w9', title: 'Transformer architecture deep dive', week: 'W13', done: false },
        { id: 'w10', title: 'Fine-tuning LLMs with Hugging Face', week: 'W15', done: false },
        { id: 'w11', title: 'RAG pipelines & vector databases', week: 'W17', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'ML System Design & Interviews', subtitle: 'Land the senior ML role',
      weeks: 'Weeks 19–24', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w12', title: 'ML system design: recommendation systems', week: 'W19', done: false },
        { id: 'w13', title: 'ML system design: fraud detection', week: 'W21', done: false },
        { id: 'w14', title: 'Portfolio: 2 production-ready ML projects', week: 'W23', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Set up MLflow experiment tracking', category: 'Learning', est: '3 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Build feature pipeline for churn dataset', category: 'Project', est: '5 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read "Designing ML Systems" Ch.5', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Implement a custom PyTorch training loop', category: 'Practice', est: '4 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Review 2 ML engineering job postings', category: 'Career', est: '1 hr', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw7', code: 'WP-06', phase: 'Production ML & MLOps',
    title: 'Feature Stores & Data Pipelines',
    description: 'Production ML fails most often at the data layer, not the model layer. This waypoint covers building reliable feature pipelines, handling training/serving skew, and working with feature stores like Feast. Navigator AI flagged this as a critical gap for your target role.',
    progress: 40, hoursLeft: 10, weeksLeft: 2,
    navigatorNote: 'Most ML interview loops include a data pipeline design question. Having a feature store you\'ve actually built gives you a concrete example to discuss under pressure.',
    resources: [
      { title: 'Feature Engineering for ML (O\'Reilly)', type: 'Book · Reading', time: '4h', done: true },
      { title: 'Feast feature store quickstart', type: 'Lab · Interactive', time: '2h', done: false },
      { title: 'Build: churn prediction feature pipeline', type: 'Project', time: '4h', done: false },
      { title: 'Training/serving skew: common pitfalls', type: 'Article', time: '45m', done: false },
    ],
  },
};

// ─── Security Engineer ────────────────────────────────────────────────────────
const securityProfile: CareerProfile = {
  goalTitle: 'Security Engineer',
  currentRole: 'IT Analyst',
  targetRole: 'Senior Security Engineer',
  category: 'Cybersecurity',
  avgSalary: '$134k',
  demand: 'Growing',
  timelineMonths: 11,
  skills: ['Network Security', 'Python', 'Penetration Testing', 'Cloud Security', 'SIEM', 'Threat Modeling'],
  navigatorNotes: [
    'IT background detected. I\'ll weight your roadmap toward threat modeling and cloud security — where the security market is growing fastest and paying most.',
    'Your foundational IT knowledge accelerates the networking security track. We\'ll move quickly through fundamentals and spend more time on cloud and application security.',
    'With your schedule set, every waypoint will include a lab environment so you gain hands-on experience — security is learned by doing.',
  ],
  radarSkills: [
    { skill: 'Network Sec', value: 65, target: 88 },
    { skill: 'App Security', value: 40, target: 85 },
    { skill: 'Cloud Sec', value: 35, target: 82 },
    { skill: 'Threat Model', value: 30, target: 80 },
    { skill: 'Python/Scripting', value: 55, target: 82 },
    { skill: 'Incident Response', value: 50, target: 85 },
  ],
  phases: [
    {
      id: 'p1', number: '01', title: 'Security Foundations', subtitle: 'Understand the threat landscape',
      weeks: 'Weeks 1–4', status: 'completed', progress: 100,
      waypoints: [
        { id: 'w1', title: 'OWASP Top 10 deep dive', week: 'W1', done: true },
        { id: 'w2', title: 'Network security fundamentals', week: 'W2', done: true },
        { id: 'w3', title: 'Linux hardening & privilege escalation', week: 'W3', done: true },
        { id: 'w4', title: 'Cryptography essentials', week: 'W4', done: true },
      ],
    },
    {
      id: 'p2', number: '02', title: 'Application & Cloud Security', subtitle: 'Defend what matters most',
      weeks: 'Weeks 5–11', status: 'active', progress: 40,
      waypoints: [
        { id: 'w5', title: 'Web application penetration testing', week: 'W5', done: true },
        { id: 'w6', title: 'AWS security: IAM, GuardDuty, CloudTrail', week: 'W6', done: false },
        { id: 'w7', title: 'Container & Kubernetes security', week: 'W7', done: false },
        { id: 'w8', title: 'SIEM with Splunk or ELK', week: 'W9', done: false },
      ],
    },
    {
      id: 'p3', number: '03', title: 'Threat Intelligence & Incident Response', subtitle: 'Detect and respond',
      weeks: 'Weeks 12–17', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w9', title: 'Threat modeling with STRIDE', week: 'W12', done: false },
        { id: 'w10', title: 'Incident response playbooks', week: 'W14', done: false },
        { id: 'w11', title: 'Forensics & log analysis', week: 'W16', done: false },
      ],
    },
    {
      id: 'p4', number: '04', title: 'Certifications & Career Prep', subtitle: 'Land the security role',
      weeks: 'Weeks 18–24', status: 'upcoming', progress: 0,
      waypoints: [
        { id: 'w12', title: 'CompTIA Security+ certification track', week: 'W18', done: false },
        { id: 'w13', title: 'CEH or OSCP lab practice', week: 'W20', done: false },
        { id: 'w14', title: 'Mock interviews: threat scenario walkthroughs', week: 'W23', done: false },
      ],
    },
  ],
  weeklyGoals: [
    { id: 'g1', title: 'Complete AWS IAM deep dive module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
    { id: 'g2', title: 'Complete HackTheBox web challenge set', category: 'Practice', est: '5 hrs', done: true, priority: 'high' },
    { id: 'g3', title: 'Read NIST Cybersecurity Framework', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
    { id: 'g4', title: 'Set up personal SIEM lab', category: 'Project', est: '4 hrs', done: false, priority: 'high' },
    { id: 'g5', title: 'Join local OWASP chapter meeting', category: 'Network', est: '2 hrs', done: false, priority: 'low' },
  ],
  currentWaypoint: {
    id: 'cw8', code: 'WP-06', phase: 'Application & Cloud Security',
    title: 'AWS Security: IAM, GuardDuty & CloudTrail',
    description: 'Cloud security misconfigurations are now the leading cause of data breaches. This waypoint covers AWS IAM least-privilege design, threat detection with GuardDuty, and audit logging with CloudTrail — essential skills for any cloud security role.',
    progress: 40, hoursLeft: 12, weeksLeft: 3,
    navigatorNote: 'Over-privileged IAM roles are the most common finding in cloud security audits. Understanding the blast radius of misconfigured policies will make you stand out in interviews immediately.',
    resources: [
      { title: 'AWS Security Specialty (A Cloud Guru)', type: 'Course · Video', time: '8h', done: true },
      { title: 'IAM least-privilege patterns', type: 'AWS Docs · Article', time: '1h', done: false },
      { title: 'Build: GuardDuty threat detection lab', type: 'Lab · Interactive', time: '3h', done: false },
      { title: 'CloudTrail log analysis with Athena', type: 'Tutorial', time: '2h', done: false },
    ],
  },
};

// ─── Generic fallback ─────────────────────────────────────────────────────────
function genericProfile(goalTitle: string): CareerProfile {
  return {
    goalTitle,
    currentRole: 'Current Role',
    targetRole: `Senior ${goalTitle}`,
    category: 'Professional',
    avgSalary: '$110k',
    demand: 'High',
    timelineMonths: 9,
    skills: ['Communication', 'Problem Solving', 'Data Analysis', 'Leadership', 'Project Management', 'Strategy'],
    navigatorNotes: [
      `Your background gives you a strong starting point. I'll weight your roadmap toward the core skills most valued for ${goalTitle} roles.`,
      'Your experience level helps me calibrate pacing. I\'ll ensure each module builds on the previous without overwhelming you.',
      'With your schedule confirmed, I\'ll structure waypoints so you make measurable progress every week.',
    ],
    radarSkills: [
      { skill: 'Core Skills', value: 60, target: 90 },
      { skill: 'Technical', value: 45, target: 80 },
      { skill: 'Leadership', value: 55, target: 85 },
      { skill: 'Communication', value: 70, target: 90 },
      { skill: 'Strategy', value: 50, target: 82 },
      { skill: 'Execution', value: 60, target: 88 },
    ],
    phases: [
      {
        id: 'p1', number: '01', title: 'Foundations', subtitle: 'Core knowledge and frameworks',
        weeks: 'Weeks 1–4', status: 'completed', progress: 100,
        waypoints: [
          { id: 'w1', title: 'Domain fundamentals', week: 'W1', done: true },
          { id: 'w2', title: 'Industry tools & workflows', week: 'W2', done: true },
          { id: 'w3', title: 'Communication & stakeholder management', week: 'W3', done: true },
          { id: 'w4', title: 'First portfolio project', week: 'W4', done: true },
        ],
      },
      {
        id: 'p2', number: '02', title: 'Core Skills', subtitle: 'Build specialized competency',
        weeks: 'Weeks 5–10', status: 'active', progress: 40,
        waypoints: [
          { id: 'w5', title: 'Advanced techniques & methodologies', week: 'W5', done: true },
          { id: 'w6', title: 'Data-driven decision making', week: 'W6', done: false },
          { id: 'w7', title: 'Cross-functional collaboration', week: 'W7', done: false },
          { id: 'w8', title: 'Build: capstone skill project', week: 'W8', done: false },
        ],
      },
      {
        id: 'p3', number: '03', title: 'Specialization', subtitle: 'Deepen your expertise',
        weeks: 'Weeks 11–16', status: 'upcoming', progress: 0,
        waypoints: [
          { id: 'w9', title: 'Advanced specialization module 1', week: 'W11', done: false },
          { id: 'w10', title: 'Advanced specialization module 2', week: 'W13', done: false },
          { id: 'w11', title: 'Industry certification prep', week: 'W15', done: false },
        ],
      },
      {
        id: 'p4', number: '04', title: 'Interview Prep & Portfolio', subtitle: 'Land the role',
        weeks: 'Weeks 17–22', status: 'upcoming', progress: 0,
        waypoints: [
          { id: 'w12', title: 'Portfolio: 3 polished projects', week: 'W17', done: false },
          { id: 'w13', title: 'Mock interviews & feedback', week: 'W20', done: false },
          { id: 'w14', title: 'Salary negotiation', week: 'W22', done: false },
        ],
      },
    ],
    weeklyGoals: [
      { id: 'g1', title: 'Complete core skills module', category: 'Learning', est: '4 hrs', done: true, priority: 'high' },
      { id: 'g2', title: 'Ship weekly project milestone', category: 'Project', est: '5 hrs', done: true, priority: 'high' },
      { id: 'g3', title: 'Read 2 industry articles', category: 'Reading', est: '2 hrs', done: false, priority: 'medium' },
      { id: 'g4', title: 'Complete practice exercises', category: 'Practice', est: '3 hrs', done: false, priority: 'high' },
      { id: 'g5', title: 'Expand professional network', category: 'Network', est: '1 hr', done: false, priority: 'low' },
    ],
    currentWaypoint: {
      id: 'cw-gen', code: 'WP-06', phase: 'Core Skills',
      title: 'Data-driven Decision Making',
      description: `This waypoint builds the analytical foundation every ${goalTitle} needs. You'll learn to structure problems, identify the right metrics, and communicate findings to stakeholders.`,
      progress: 40, hoursLeft: 9, weeksLeft: 2,
      navigatorNote: `Strong ${goalTitle}s distinguish themselves by making decisions backed by data, not intuition alone. This section will give you that foundation.`,
      resources: [
        { title: 'Data-driven thinking fundamentals', type: 'Video Course', time: '3h', done: true },
        { title: 'Metrics that matter in your field', type: 'Article', time: '45m', done: false },
        { title: 'Build: analysis report for a real problem', type: 'Project', time: '4h', done: false },
        { title: 'Presenting data to non-technical audiences', type: 'Video', time: '1h 30m', done: false },
      ],
    },
  };
}

// ─── Provider ─────────────────────────────────────────────────────────────────
export function CareerProvider({ children }: { children: ReactNode }) {
  const [goalInput, setGoalInputRaw] = useState<string>(() => {
    try { return localStorage.getItem('careeros_goal') ?? ''; } catch { return ''; }
  });
  const [experience, setExperienceRaw] = useState<string>(() => {
    try { return localStorage.getItem('careeros_exp') ?? 'mid'; } catch { return 'mid'; }
  });
  const [weeklyHours, setWeeklyHoursRaw] = useState<number>(() => {
    try { return Number(localStorage.getItem('careeros_hours') ?? '8'); } catch { return 8; }
  });
  const [selectedSkills, setSelectedSkillsRaw] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem('careeros_skills') ?? '[]'); } catch { return []; }
  });

  const setGoalInput = (g: string) => {
    setGoalInputRaw(g);
    try { localStorage.setItem('careeros_goal', g); } catch {}
  };
  const setExperience = (e: string) => {
    setExperienceRaw(e);
    try { localStorage.setItem('careeros_exp', e); } catch {}
  };
  const setWeeklyHours = (h: number) => {
    setWeeklyHoursRaw(h);
    try { localStorage.setItem('careeros_hours', String(h)); } catch {}
  };
  const setSelectedSkills = (s: string[]) => {
    setSelectedSkillsRaw(s);
    try { localStorage.setItem('careeros_skills', JSON.stringify(s)); } catch {}
  };

  const profile = buildProfile(goalInput);

  return (
    <CareerContext.Provider value={{ goalInput, setGoalInput, profile, experience, setExperience, weeklyHours, setWeeklyHours, selectedSkills, setSelectedSkills }}>
      {children}
    </CareerContext.Provider>
  );
}
